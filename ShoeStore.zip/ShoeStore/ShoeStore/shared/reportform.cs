﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeStore.shared
{
    public partial class reportform : Form
    {
        public reportform()
        {
            InitializeComponent();
        }

        private void returnbut_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
