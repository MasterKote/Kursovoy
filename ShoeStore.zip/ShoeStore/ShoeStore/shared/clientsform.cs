﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace ShoeStore.manager
{
    public partial class clientsform : Form
    {
        private string conStr = "server=localhost;uid=root;database=shoestore_db;pwd=root;";
        private int currentPage = 1;
        private int totalPages = 1;
        private const int PageSize = 20;

        public clientsform()
        {
            InitializeComponent();
            this.Load += clientsform_Load;
        }

        private void clientsform_Load(object sender, EventArgs e)
        {
            // Создание панели пагинации справа от полей ввода
            FlowLayoutPanel flowPagination = new FlowLayoutPanel();
            flowPagination.Location = new Point(465, 255);
            flowPagination.Size = new Size(210, 130);
            flowPagination.AutoScroll = true;
            flowPagination.Name = "flowPagination";
            this.Controls.Add(flowPagination);

            textBox1.TextChanged += RealTime_Changed;

            RefreshGrid();
        }

        // Сброс на первую страницу и обновление таблицы при вводе в поле поиска
        private void RealTime_Changed(object sender, EventArgs e)
        {
            currentPage = 1;
            RefreshGrid();
        }

        // Загрузка списка клиентов из БД с учетом поиска и пагинации
        private void RefreshGrid()
        {
            // Текст для поиска по ФИО клиента
            string search = textBox1.Text.Trim();

            string whereSql = "";
            if (search.Length > 0)
                whereSql = " WHERE c.ClientFIO LIKE @search";

            string sql = @"SELECT c.ClientId, c.ClientFIO, c.ClientPhone
                           FROM client c" + whereSql + " ORDER BY c.ClientFIO";

            try
            {
                using (MySqlConnection con = new MySqlConnection(conStr))
                {
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, con);
                    if (search.Length > 0)
                        cmd.Parameters.AddWithValue("@search", "%" + search + "%");

                    // Загрузка полной выборки из БД
                    DataTable full = new DataTable();
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(full);

                    // Расчет общего количества страниц
                    int total = full.Rows.Count;
                    totalPages = (int)Math.Ceiling(total / (double)PageSize);
                    if (totalPages < 1) totalPages = 1;
                    if (currentPage > totalPages) currentPage = totalPages;

                    // Выбор строк текущей страницы
                    int start = (currentPage - 1) * PageSize;
                    int count = Math.Min(PageSize, Math.Max(0, total - start));

                    // Копирование записей текущей страницы в отдельную таблицу
                    DataTable page = full.Clone();
                    for (int i = 0; i < count; i++)
                        page.ImportRow(full.Rows[start + i]);

                    // Привязка данных и оформление таблицы
                    dataGridView1.DataSource = page;
                    SetupColumns(); // колонки и маскирование телефона
                    RenderPagination(totalPages); // отрисовка кнопок пагинации
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Настройка колонок таблицы клиентов
        private void SetupColumns()
        {
            // Служебные колонки скрываются
            if (dataGridView1.Columns["ClientId"] != null) dataGridView1.Columns["ClientId"].Visible = false;
            if (dataGridView1.Columns["ClientPhone"] != null) dataGridView1.Columns["ClientPhone"].Visible = false;

            // Колонка с ФИО клиента
            if (dataGridView1.Columns["ClientFIO"] != null)
            {
                dataGridView1.Columns["ClientFIO"].HeaderText = "ФИО клиента";
                dataGridView1.Columns["ClientFIO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }

            // Колонка с замаскированным телефоном
            if (!dataGridView1.Columns.Contains("colPhone"))
            {
                DataGridViewTextBoxColumn phoneCol = new DataGridViewTextBoxColumn();
                phoneCol.Name = "colPhone";
                phoneCol.HeaderText = "Телефон";
                phoneCol.Width = 150;
                dataGridView1.Columns.Add(phoneCol);
            }
            dataGridView1.Columns["colPhone"].DisplayIndex = 1;

            dataGridView1.ColumnHeadersVisible = false;
            dataGridView1.RowTemplate.Height = 30;

            // Маскирование номеров телефонов
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                string phone = GetCellValue(row, "ClientPhone");
                row.Cells["colPhone"].Value = MaskPhone(phone);
            }
        }

        // Безопасное получение значения ячейки в виде строки
        private string GetCellValue(DataGridViewRow row, string colName)
        {
            if (dataGridView1.Columns[colName] == null) return "";
            object v = row.Cells[colName].Value;
            return v == null || v == DBNull.Value ? "" : v.ToString();
        }

        // Маскирование номера телефона
        private string MaskPhone(string phone)
        {
            if (string.IsNullOrEmpty(phone))
                return "+7 (***) ***-**-**";
            return "+7 (***) ***-**-**";
        }

        // Отрисовка кнопок пагинации
        private void RenderPagination(int pages)
        {
            var flow = this.Controls.Find("flowPagination", false);
            if (flow.Length == 0) return;
            FlowLayoutPanel flp = (FlowLayoutPanel)flow[0];
            flp.Controls.Clear();

            // Кнопка перехода на первую страницу
            Button btnFirst = CreateNavButton("|◀", currentPage > 1);
            btnFirst.Click += (s, ev) => { currentPage = 1; RefreshGrid(); };
            flp.Controls.Add(btnFirst);

            // Кнопка перехода на предыдущую страницу
            Button btnPrev = CreateNavButton("◀", currentPage > 1);
            btnPrev.Click += (s, ev) => { if (currentPage > 1) { currentPage--; RefreshGrid(); } };
            flp.Controls.Add(btnPrev);

            // Кнопки с номерами всех страниц, текущая выделяется цветом
            for (int i = 1; i <= pages; i++)
            {
                Button btn = new Button();
                btn.Text = i.ToString();
                btn.Size = new Size(35, 28);
                btn.FlatStyle = FlatStyle.Flat;
                btn.Margin = new Padding(2);
                if (i == currentPage)
                {
                    // Текущая страница выделяется оранжевым фоном
                    btn.Enabled = true;
                    btn.BackColor = Color.FromArgb(204, 102, 0);
                    btn.ForeColor = Color.White;
                }
                else
                {
                    btn.Enabled = true;
                    btn.BackColor = Color.White;
                    btn.ForeColor = Color.Black;
                }
                int page = i;
                btn.Click += (s, ev) => { currentPage = page; RefreshGrid(); };
                flp.Controls.Add(btn);
            }

            // Кнопка перехода на следующую страницу
            Button btnNext = CreateNavButton("▶", currentPage < pages);
            btnNext.Click += (s, ev) => { if (currentPage < totalPages) { currentPage++; RefreshGrid(); } };
            flp.Controls.Add(btnNext);

            // Кнопка перехода на последнюю страницу
            Button btnLast = CreateNavButton("▶|", currentPage < pages);
            btnLast.Click += (s, ev) => { currentPage = totalPages; RefreshGrid(); };
            flp.Controls.Add(btnLast);
        }

        // Создание навигационной кнопки пагинации
        private Button CreateNavButton(string text, bool enabled)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.Size = new Size(40, 28);
            btn.FlatStyle = FlatStyle.Flat;
            btn.Margin = new Padding(2);
            btn.Enabled = enabled;
            btn.BackColor = enabled ? Color.White : Color.FromArgb(240, 240, 240);
            btn.ForeColor = Color.Black;
            return btn;
        }

        private void returnbut_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
