using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace ShoeStore.shared
{
    public partial class ordersform : Form
    {
        private string conStr = "server=localhost;uid=root;database=shoestore_db;pwd=root;";

        public ordersform()
        {
            InitializeComponent();
            this.Load += ordersform_Load;
        }

        private void ordersform_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox1.Items.Add("Все клиенты");
            try
            {
                using (MySqlConnection con = new MySqlConnection(conStr))
                {
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand(
                        "SELECT ClientFIO FROM client ORDER BY ClientFIO", con);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                            comboBox1.Items.Add(reader.GetString(0));
                    }
                }
            }
            catch { }
            comboBox1.SelectedIndex = 0;

            comboBox2.Items.Clear();
            comboBox2.Items.Add("Все сотрудники");
            try
            {
                using (MySqlConnection con = new MySqlConnection(conStr))
                {
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand(
                        "SELECT WorkerFIO FROM worker ORDER BY WorkerFIO", con);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                            comboBox2.Items.Add(reader.GetString(0));
                    }
                }
            }
            catch { }
            comboBox2.SelectedIndex = 0;

            // Фильтрация заказов при выборе клиента или сотрудника
            comboBox1.SelectedIndexChanged += RealTime_Changed;
            comboBox2.SelectedIndexChanged += RealTime_Changed;

            // Подключение условного форматирования строк (цвет по статусу заказа)
            dataGridView1.CellFormatting += dataGridView1_CellFormatting;

            RefreshGrid();
        }

        // Обновление таблицы при изменении выбранного клиента или сотрудника
        private void RealTime_Changed(object sender, EventArgs e)
        {
            RefreshGrid();
        }

        // Загрузка заказов из БД с учетом фильтров по клиенту и сотруднику
        private void RefreshGrid()
        {
            // Выбранный клиент для фильтрации
            string client = comboBox1.SelectedItem?.ToString() ?? "Все клиенты";
            // Выбранный сотрудник для фильтрации
            string worker = comboBox2.SelectedItem?.ToString() ?? "Все сотрудники";

            List<string> conditions = new List<string>();
            if (client != "Все клиенты")
                conditions.Add("c.ClientFIO = @client");
            if (worker != "Все сотрудники")
                conditions.Add("w.WorkerFIO = @worker");

            string whereSql = conditions.Count > 0 ? " WHERE " + string.Join(" AND ", conditions) : "";

            string sql = @"SELECT o.OrderId, o.OrderDate, c.ClientFIO, w.WorkerFIO,
                                  o.OrderPrice, o.OrderStatus, o.OrderStatusPayment
                           FROM `order` o
                           JOIN client c ON o.ClientId = c.ClientId
                           JOIN worker w ON o.WorkerId = w.WorkerId"
                           + whereSql + " ORDER BY o.OrderDate DESC";

            try
            {
                using (MySqlConnection con = new MySqlConnection(conStr))
                {
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, con);
                    if (client != "Все клиенты")
                        cmd.Parameters.AddWithValue("@client", client);
                    if (worker != "Все сотрудники")
                        cmd.Parameters.AddWithValue("@worker", worker);

                    // Загрузка данных из БД
                    DataTable dt = new DataTable();
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(dt);

                    // Привязка данных и оформление таблицы
                    dataGridView1.DataSource = dt;
                    SetupColumns();        // настройка колонок и форматирование значений
                    dataGridView1.Refresh(); // применение условного форматирования
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Настройка колонок таблицы заказов
        private void SetupColumns()
        {
            // Служебные колонки скрываются, данные выводятся в форматированные колонки
            if (dataGridView1.Columns["OrderId"] != null) dataGridView1.Columns["OrderId"].Visible = false;
            if (dataGridView1.Columns["OrderDate"] != null) dataGridView1.Columns["OrderDate"].Visible = false;
            if (dataGridView1.Columns["OrderPrice"] != null) dataGridView1.Columns["OrderPrice"].Visible = false;

            // Колонка с номером заказа
            if (!dataGridView1.Columns.Contains("colNum"))
            {
                DataGridViewTextBoxColumn numCol = new DataGridViewTextBoxColumn();
                numCol.Name = "colNum";
                numCol.HeaderText = "№";
                numCol.Width = 50;
                dataGridView1.Columns.Add(numCol);
            }
            dataGridView1.Columns["colNum"].DisplayIndex = 0;

            // Колонка с датой заказа в формате дд.мм.гггг чч:мм
            if (!dataGridView1.Columns.Contains("colDate"))
            {
                DataGridViewTextBoxColumn dateCol = new DataGridViewTextBoxColumn();
                dateCol.Name = "colDate";
                dateCol.HeaderText = "Дата";
                dateCol.Width = 120;
                dataGridView1.Columns.Add(dateCol);
            }
            dataGridView1.Columns["colDate"].DisplayIndex = 1;

            // Колонка с ФИО клиента
            if (dataGridView1.Columns["ClientFIO"] != null)
            {
                dataGridView1.Columns["ClientFIO"].HeaderText = "Клиент";
                dataGridView1.Columns["ClientFIO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dataGridView1.Columns["ClientFIO"].DisplayIndex = 2;
            }

            // Колонка с ФИО сотрудника
            if (dataGridView1.Columns["WorkerFIO"] != null)
            {
                dataGridView1.Columns["WorkerFIO"].HeaderText = "Сотрудник";
                dataGridView1.Columns["WorkerFIO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dataGridView1.Columns["WorkerFIO"].DisplayIndex = 3;
            }

            // Колонка с итоговой суммой заказа
            if (!dataGridView1.Columns.Contains("colSum"))
            {
                DataGridViewTextBoxColumn sumCol = new DataGridViewTextBoxColumn();
                sumCol.Name = "colSum";
                sumCol.HeaderText = "Сумма";
                sumCol.Width = 100;
                dataGridView1.Columns.Add(sumCol);
            }
            dataGridView1.Columns["colSum"].DisplayIndex = 4;

            // Колонка статуса заказа
            if (dataGridView1.Columns["OrderStatus"] != null)
            {
                dataGridView1.Columns["OrderStatus"].HeaderText = "Статус";
                dataGridView1.Columns["OrderStatus"].Width = 100;
                dataGridView1.Columns["OrderStatus"].DisplayIndex = 5;
            }

            // Колонка статуса оплаты
            if (dataGridView1.Columns["OrderStatusPayment"] != null)
            {
                dataGridView1.Columns["OrderStatusPayment"].HeaderText = "Оплата";
                dataGridView1.Columns["OrderStatusPayment"].Width = 100;
                dataGridView1.Columns["OrderStatusPayment"].DisplayIndex = 6;
            }

            dataGridView1.ColumnHeadersVisible = false;
            dataGridView1.RowTemplate.Height = 30;

            // Заполнение форматированных колонок значениями из БД
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                // Номер заказа
                row.Cells["colNum"].Value = GetCellValue(row, "OrderId");

                // Дата читается напрямую как DateTime из ячейки
                object dateObj = row.Cells["OrderDate"].Value;
                if (dateObj != null && dateObj is DateTime)
                    row.Cells["colDate"].Value = ((DateTime)dateObj).ToString("dd.MM.yyyy HH:mm");
                else
                    row.Cells["colDate"].Value = GetCellValue(row, "OrderDate");
                object priceObj = row.Cells["OrderPrice"].Value;
                decimal priceVal = (priceObj != null && priceObj != DBNull.Value)
                    ? Convert.ToDecimal(priceObj) : 0;
                row.Cells["colSum"].Value = priceVal.ToString("N2") + " руб.";
            }
        }

        // Безопасное получение значения ячейки в виде строки
        private string GetCellValue(DataGridViewRow row, string colName)
        {
            if (dataGridView1.Columns[colName] == null) return "";
            object v = row.Cells[colName].Value;
            return v == null || v == DBNull.Value ? "" : v.ToString();
        }

        // Условное форматирование строк по статусу заказа и оплаты
        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= dataGridView1.Rows.Count) return;

            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            string status = GetCellValue(row, "OrderStatus");
            string payment = GetCellValue(row, "OrderStatusPayment");

            // Цвет строки по умолчанию — белый
            Color backColor = Color.White;

            // Подсветка по статусу заказа
            if (status == "Выполнен")
                backColor = Color.FromArgb(180, 255, 180);   // зеленый — выполнен
            else if (status == "Отменён")
                backColor = Color.FromArgb(200, 200, 200);   // серый — отменен
            else if (status == "Ожидание")
                backColor = Color.FromArgb(255, 180, 180);   // красный — ожидание
            else if (status == "В процессе")
                backColor = Color.FromArgb(180, 220, 255);   // голубой — в процессе

            // Возврат оплаты перекрывает цвет статуса
            if (payment == "Возврат")
                backColor = Color.FromArgb(255, 150, 150);   // ярко-красный — возврат

            e.CellStyle.BackColor = backColor;
        }

        private void returnbut_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
