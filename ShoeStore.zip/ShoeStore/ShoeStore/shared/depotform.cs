using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace ShoeStore.admin
{
    public partial class depotform : Form
    {
        private string conStr = "server=localhost;uid=root;database=shoestore_db;pwd=root;";
        private int currentPage = 1;
        private int totalPages = 1;
        private const int PageSize = 20;

        // Кэш изображений
        private static Dictionary<string, Image> imageCache = new Dictionary<string, Image>();

        public depotform()
        {
            InitializeComponent();
            this.Load += depotform_Load;
        }

        private void depotform_Load(object sender, EventArgs e)
        {
            // Создание панели пагинации под таблицей
            FlowLayoutPanel flowPagination = new FlowLayoutPanel();
            flowPagination.Location = new Point(195, 350);
            flowPagination.Size = new Size(440, 35);
            flowPagination.AutoScroll = true;
            flowPagination.Name = "flowPagination";
            this.Controls.Add(flowPagination);

            comboBox1.Items.Clear();
            comboBox1.Items.Add("Все бренды");
            try
            {
                using (MySqlConnection con = new MySqlConnection(conStr))
                {
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand("SELECT BrandName FROM brand ORDER BY BrandName", con);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                            comboBox1.Items.Add(reader.GetString(0));
                    }
                }
            }
            catch { }
            comboBox1.SelectedIndex = 0;

            comboBox2.Items.Clear();
            comboBox2.Items.Add("Без сортировки");
            comboBox2.Items.Add("По возрастанию цены");
            comboBox2.Items.Add("По убыванию цены");
            comboBox2.SelectedIndex = 0;
            textBox1.TextChanged += RealTime_Changed;
            comboBox1.SelectedIndexChanged += RealTime_Changed;
            comboBox2.SelectedIndexChanged += RealTime_Changed;

            RefreshGrid();
        }

        // Сброс на первую страницу и обновление таблицы при изменении поиска/фильтра/сортировки
        private void RealTime_Changed(object sender, EventArgs e)
        {
            currentPage = 1;
            RefreshGrid();
        }

        // Загрузка данных из БД с учетом поиска, фильтра, сортировки и пагинации
        private void RefreshGrid()
        {
            // Текст для поиска по наименованию товара
            string search = textBox1.Text.Trim();
            // Выбранный бренд для фильтрации
            string brand = comboBox1.SelectedItem?.ToString() ?? "Все бренды";
            // Выбранный вариант сортировки
            int sortIdx = comboBox2.SelectedIndex;

            // Формирование условий WHERE для поиска и фильтра
            List<string> conditions = new List<string>();
            if (search.Length > 0)
                conditions.Add("s.ShoesName LIKE @search");
            if (brand != "Все бренды")
                conditions.Add("b.BrandName = @brand");

            string whereSql = conditions.Count > 0 ? " WHERE " + string.Join(" AND ", conditions) : "";

            string orderSql = "";
            if (sortIdx == 1) orderSql = " ORDER BY s.ShoesPrice ASC";
            else if (sortIdx == 2) orderSql = " ORDER BY s.ShoesPrice DESC";

            string sql = @"SELECT s.ShoesId, s.ShoesName, s.ShoesDescription, s.ShoesSize,
                                  s.ShoesColor, s.ShoesPrice, s.ShoesQuantity, s.ShoesPhoto,
                                  b.BrandName, c.CategoryShoesName, o.OffersShoesDiscount
                           FROM shoes s
                           JOIN brand b ON s.BrandId = b.BrandId
                           JOIN categoryshoes c ON s.ShoesCategory = c.CategoryShoesId
                           JOIN offersshoes o ON s.OffersShoes = o.OffersShoesId"
                           + whereSql + orderSql;

            try
            {
                using (MySqlConnection con = new MySqlConnection(conStr))
                {
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, con);
                    if (search.Length > 0)
                        cmd.Parameters.AddWithValue("@search", "%" + search + "%");
                    if (brand != "Все бренды")
                        cmd.Parameters.AddWithValue("@brand", brand);

                    // Загрузка полной выборки из БД
                    DataTable full = new DataTable();
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(full);

                    // Расчет общего количества страниц
                    int total = full.Rows.Count;
                    totalPages = (int)Math.Ceiling(total / (double)PageSize);
                    if (totalPages < 1) totalPages = 1;
                    if (currentPage > totalPages) currentPage = totalPages;

                    // Выбор строк текущей страницы
                    int start = (currentPage - 1) * PageSize;
                    int count = Math.Min(PageSize, Math.Max(0, total - start));

                    // Копирование записей текущей страницы в отдельную таблицу
                    DataTable page = full.Clone();
                    for (int i = 0; i < count; i++)
                        page.ImportRow(full.Rows[start + i]);

                    // Привязка данных и оформление таблицы
                    dataGridView1.DataSource = page;
                    SetupColumns();      // настройка колонок и карточек товаров
                    ApplyImages();       // подстановка изображений обуви
                    ApplyHighlight();    // условное форматирование строк
                    RenderPagination(totalPages); // отрисовка кнопок пагинации
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Карточка товара с изображением и характеристиками
        private void SetupColumns()
        {
            // Служебные колонки скрываются
            if (dataGridView1.Columns["ShoesId"] != null) dataGridView1.Columns["ShoesId"].Visible = false;
            if (dataGridView1.Columns["ShoesPhoto"] != null) dataGridView1.Columns["ShoesPhoto"].Visible = false;

            // Колонка изображения товара
            if (!dataGridView1.Columns.Contains("colPhoto"))
            {
                DataGridViewImageColumn imgCol = new DataGridViewImageColumn();
                imgCol.Name = "colPhoto";
                imgCol.HeaderText = "";
                imgCol.ImageLayout = DataGridViewImageCellLayout.Zoom;
                imgCol.Width = 80;
                dataGridView1.Columns.Add(imgCol);
            }
            dataGridView1.Columns["colPhoto"].DisplayIndex = 0;

            // Колонка текстовой информации о товаре
            if (!dataGridView1.Columns.Contains("colInfo"))
            {
                DataGridViewTextBoxColumn infoCol = new DataGridViewTextBoxColumn();
                infoCol.Name = "colInfo";
                infoCol.HeaderText = "";
                infoCol.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                dataGridView1.Columns.Add(infoCol);
            }
            dataGridView1.Columns["colInfo"].DisplayIndex = 1;
            dataGridView1.Columns["colInfo"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            // Исходные колонки скрываются, данные выводятся в colInfo
            string[] hideCols = { "ShoesName", "ShoesDescription", "ShoesSize", "ShoesColor",
                                   "ShoesPrice", "BrandName", "CategoryShoesName" };
            foreach (string col in hideCols)
                if (dataGridView1.Columns[col] != null) dataGridView1.Columns[col].Visible = false;

            // Видимые колонки: размер скидки и остаток на складе
            if (dataGridView1.Columns["OffersShoesDiscount"] != null)
            {
                dataGridView1.Columns["OffersShoesDiscount"].HeaderText = "Скидка";
                dataGridView1.Columns["OffersShoesDiscount"].Width = 80;
                dataGridView1.Columns["OffersShoesDiscount"].DisplayIndex = 2;
            }

            if (dataGridView1.Columns["ShoesQuantity"] != null)
            {
                dataGridView1.Columns["ShoesQuantity"].HeaderText = "Остаток";
                dataGridView1.Columns["ShoesQuantity"].Width = 80;
                dataGridView1.Columns["ShoesQuantity"].DisplayIndex = 3;
            }

            dataGridView1.ColumnHeadersVisible = false;
            dataGridView1.RowTemplate.Height = 80;

            // Формирование многострочной карточки товара в каждой строке
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                string name = GetCellValue(row, "ShoesName");
                string desc = GetCellValue(row, "ShoesDescription");
                string brand = GetCellValue(row, "BrandName");
                string cat = GetCellValue(row, "CategoryShoesName");
                string size = GetCellValue(row, "ShoesSize");
                string color = GetCellValue(row, "ShoesColor");
                object priceObj = row.Cells["ShoesPrice"].Value;
                decimal priceVal = (priceObj != null && priceObj != DBNull.Value)
                    ? Convert.ToDecimal(priceObj) : 0;

                row.Cells["colInfo"].Value = name + Environment.NewLine
                    + desc + Environment.NewLine
                    + "Бренд: " + brand + Environment.NewLine
                    + "Категория: " + cat + Environment.NewLine
                    + "Размер: " + size + "  Цвет: " + color + Environment.NewLine
                    + "Цена: " + priceVal.ToString("N2") + " руб.";
            }
        }

        // Безопасное получение значения ячейки в виде строки
        private string GetCellValue(DataGridViewRow row, string colName)
        {
            if (dataGridView1.Columns[colName] == null) return "";
            object v = row.Cells[colName].Value;
            return v == null || v == DBNull.Value ? "" : v.ToString();
        }

        // Подстановка изображений обуви в колонку colPhoto для каждой строки
        private void ApplyImages()
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                string photo = GetCellValue(row, "ShoesPhoto");
                row.Cells["colPhoto"].Value = GetShoeImage(photo);
            }
        }

        // Условное форматирование строк: красный — нет в наличии, зеленый — акционный товар
        private void ApplyHighlight()
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                // Текущий остаток товара
                int quantity = 0;
                object v = row.Cells["ShoesQuantity"].Value;
                if (v != null && v != DBNull.Value) quantity = Convert.ToInt32(v);

                // Размер скидки из акции
                int discount = 0;
                object d = row.Cells["OffersShoesDiscount"].Value;
                if (d != null && d != DBNull.Value) discount = Convert.ToInt32(d);

                // Красный фон — товар закончился, зеленый — действует скидка
                if (quantity == 0)
                    row.DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(255, 180, 180) };
                else if (discount > 0)
                    row.DefaultCellStyle = new DataGridViewCellStyle { BackColor = Color.FromArgb(180, 255, 180) };
            }
        }

        // Отрисовка кнопок пагинации
        private void RenderPagination(int pages)
        {
            var flow = this.Controls.Find("flowPagination", false);
            if (flow.Length == 0) return;
            FlowLayoutPanel flp = (FlowLayoutPanel)flow[0];
            flp.Controls.Clear();

            // Кнопка перехода на первую страницу
            Button btnFirst = CreateNavButton("|◀", currentPage > 1);
            btnFirst.Click += (s, ev) => { currentPage = 1; RefreshGrid(); };
            flp.Controls.Add(btnFirst);

            // Кнопка перехода на предыдущую страницу
            Button btnPrev = CreateNavButton("◀", currentPage > 1);
            btnPrev.Click += (s, ev) => { if (currentPage > 1) { currentPage--; RefreshGrid(); } };
            flp.Controls.Add(btnPrev);

            // Кнопки с номерами всех страниц, текущая выделяется цветом
            for (int i = 1; i <= pages; i++)
            {
                Button btn = new Button();
                btn.Text = i.ToString();
                btn.Size = new Size(35, 28);
                btn.FlatStyle = FlatStyle.Flat;
                btn.Margin = new Padding(2);
                if (i == currentPage)
                {
                    // Текущая страница выделяется оранжевым фоном
                    btn.Enabled = true;
                    btn.BackColor = Color.FromArgb(204, 102, 0);
                    btn.ForeColor = Color.White;
                }
                else
                {
                    btn.Enabled = true;
                    btn.BackColor = Color.White;
                    btn.ForeColor = Color.Black;
                }
                int page = i;
                btn.Click += (s, ev) => { currentPage = page; RefreshGrid(); };
                flp.Controls.Add(btn);
            }

            // Кнопка перехода на следующую страницу
            Button btnNext = CreateNavButton("▶", currentPage < pages);
            btnNext.Click += (s, ev) => { if (currentPage < totalPages) { currentPage++; RefreshGrid(); } };
            flp.Controls.Add(btnNext);

            // Кнопка перехода на последнюю страницу
            Button btnLast = CreateNavButton("▶|", currentPage < pages);
            btnLast.Click += (s, ev) => { currentPage = totalPages; RefreshGrid(); };
            flp.Controls.Add(btnLast);
        }

        // Создание навигационной кнопки пагинации
        private Button CreateNavButton(string text, bool enabled)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.Size = new Size(40, 28);
            btn.FlatStyle = FlatStyle.Flat;
            btn.Margin = new Padding(2);
            btn.Enabled = enabled;
            btn.BackColor = enabled ? Color.White : Color.FromArgb(240, 240, 240);
            btn.ForeColor = Color.Black;
            return btn;
        }

        // Загрузка изображения товара
        private Image GetShoeImage(string photo)
        {
            // Заглушка image.png
            string fileName = string.IsNullOrWhiteSpace(photo)
                ? "image.png"
                : Path.GetFileName(photo.Trim());

            // Проверка кэша загруженных изображений
            if (imageCache.ContainsKey(fileName))
                return imageCache[fileName];

            string folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
                                         "Resources", "images", "shoes");
            string path = Path.Combine(folder, fileName);

            // Если файл по пути из БД не найден — подставляется заглушка
            if (!File.Exists(path))
            {
                fileName = "image.png";
                path = Path.Combine(folder, fileName);
                if (imageCache.ContainsKey(fileName))
                    return imageCache[fileName];
            }

            // Загрузка файла изображения
            Image img;
            try
            {
                if (File.Exists(path))
                {
                    using (MemoryStream ms = new MemoryStream(File.ReadAllBytes(path)))
                        img = new Bitmap(Image.FromStream(ms));
                }
                else
                {
                    img = new Bitmap(60, 60);
                }
            }
            catch
            {
                img = new Bitmap(60, 60);
            }

            // Сохранение изображения в кэш
            imageCache[fileName] = img;
            return img;
        }

        private void returnbut_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
