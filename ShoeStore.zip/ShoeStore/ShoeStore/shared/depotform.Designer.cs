﻿
namespace ShoeStore.admin
{
    partial class depotform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(depotform));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.returnbut = new System.Windows.Forms.Button();
            this.addbut = new System.Windows.Forms.Button();
            this.redactbut = new System.Windows.Forms.Button();
            this.delbut = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(1, 1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(685, 265);
            this.dataGridView1.TabIndex = 0;
            // 
            // returnbut
            // 
            this.returnbut.Location = new System.Drawing.Point(592, 386);
            this.returnbut.Name = "returnbut";
            this.returnbut.Size = new System.Drawing.Size(94, 33);
            this.returnbut.TabIndex = 1;
            this.returnbut.Text = "Назад";
            this.returnbut.UseVisualStyleBackColor = true;
            // 
            // addbut
            // 
            this.addbut.Location = new System.Drawing.Point(12, 272);
            this.addbut.Name = "addbut";
            this.addbut.Size = new System.Drawing.Size(158, 40);
            this.addbut.TabIndex = 7;
            this.addbut.Text = "Добавить";
            this.addbut.UseVisualStyleBackColor = true;
            // 
            // redactbut
            // 
            this.redactbut.Enabled = false;
            this.redactbut.Location = new System.Drawing.Point(12, 318);
            this.redactbut.Name = "redactbut";
            this.redactbut.Size = new System.Drawing.Size(158, 40);
            this.redactbut.TabIndex = 6;
            this.redactbut.Text = "Редактировать";
            this.redactbut.UseVisualStyleBackColor = true;
            // 
            // delbut
            // 
            this.delbut.Enabled = false;
            this.delbut.Location = new System.Drawing.Point(12, 364);
            this.delbut.Name = "delbut";
            this.delbut.Size = new System.Drawing.Size(158, 40);
            this.delbut.TabIndex = 5;
            this.delbut.Text = "Удалить";
            this.delbut.UseVisualStyleBackColor = true;
            // 
            // depotadminform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 420);
            this.Controls.Add(this.addbut);
            this.Controls.Add(this.redactbut);
            this.Controls.Add(this.delbut);
            this.Controls.Add(this.returnbut);
            this.Controls.Add(this.dataGridView1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "depotadminform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Склад";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button returnbut;
        private System.Windows.Forms.Button addbut;
        private System.Windows.Forms.Button redactbut;
        private System.Windows.Forms.Button delbut;
    }
}