﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ShoeStore
{
    public partial class employesadminform : Form
    {
        private string conStr = "server=localhost;uid=root;database=shoestore_db;pwd=root;";
        private int currentPage = 1;
        private int totalPages = 1;
        private const int PageSize = 20;

        public employesadminform()
        {
            InitializeComponent();
            this.Load += employesadminform_Load;
        }
        private void employesadminform_Load(object sender, EventArgs e)
        {
            // Создание панели пагинации под таблицей
            FlowLayoutPanel flowPagination = new FlowLayoutPanel();
            flowPagination.Location = new Point(176, 350);
            flowPagination.Size = new Size(400, 35);
            flowPagination.AutoScroll = true;
            flowPagination.Name = "flowPagination";
            this.Controls.Add(flowPagination);
            textBox1.TextChanged += RealTime_Changed;

            RefreshGrid();
        }

        // Сброс на первую страницу и обновление таблицы при вводе в поле поиска
        private void RealTime_Changed(object sender, EventArgs e)
        {
            currentPage = 1;
            RefreshGrid();
        }

        // Загрузка списка сотрудников из БД с учетом поиска и пагинации
        private void RefreshGrid()
        {
            // Текст для поиска по ФИО сотрудника
            string search = textBox1.Text.Trim();

            // Формирование условия WHERE для поиска
            string whereSql = "";
            if (search.Length > 0)
                whereSql = " WHERE w.WorkerFIO LIKE @search";

            // SQL-запрос: данные сотрудника с названием роли
            string sql = @"SELECT w.WorkerId, w.WorkerFIO, r.RoleName, w.WorkerPhone,
                                  w.WorkerPassport, w.WorkerLogin
                           FROM worker w
                           JOIN role r ON w.WorkerRole = r.RoleId"
                           + whereSql + " ORDER BY w.WorkerFIO";

            try
            {
                using (MySqlConnection con = new MySqlConnection(conStr))
                {
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand(sql, con);
                    // Параметризованный запрос для защиты от SQL-инъекций
                    if (search.Length > 0)
                        cmd.Parameters.AddWithValue("@search", "%" + search + "%");

                    // Загрузка полной выборки из БД
                    DataTable full = new DataTable();
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(full);

                    // Расчет общего количества страниц
                    int total = full.Rows.Count;
                    totalPages = (int)Math.Ceiling(total / (double)PageSize);
                    if (totalPages < 1) totalPages = 1;
                    if (currentPage > totalPages) currentPage = totalPages;

                    // Выбор строк текущей страницы
                    int start = (currentPage - 1) * PageSize;
                    int count = Math.Min(PageSize, Math.Max(0, total - start));

                    // Копирование записей текущей страницы в отдельную таблицу
                    DataTable page = full.Clone();
                    for (int i = 0; i < count; i++)
                        page.ImportRow(full.Rows[start + i]);

                    // Привязка данных и оформление таблицы
                    dataGridView1.DataSource = page;
                    SetupColumns();  // карточка сотрудника с маскированием данных
                    ApplyImages();   // подстановка изображения пользователя
                    RenderPagination(totalPages); // отрисовка кнопок пагинации
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Настройка внешнего вида таблицы: карточка сотрудника с изображением
        private void SetupColumns()
        {
            // Служебная колонка скрывается
            if (dataGridView1.Columns["WorkerId"] != null) dataGridView1.Columns["WorkerId"].Visible = false;

            // Колонка изображения пользователя (создается один раз)
            if (!dataGridView1.Columns.Contains("colPhoto"))
            {
                DataGridViewImageColumn imgCol = new DataGridViewImageColumn();
                imgCol.Name = "colPhoto";
                imgCol.HeaderText = "";
                imgCol.ImageLayout = DataGridViewImageCellLayout.Zoom;
                imgCol.Width = 80;
                dataGridView1.Columns.Add(imgCol);
            }
            dataGridView1.Columns["colPhoto"].DisplayIndex = 0;

            // Колонка текстовой информации о сотруднике (создается один раз)
            if (!dataGridView1.Columns.Contains("colInfo"))
            {
                DataGridViewTextBoxColumn infoCol = new DataGridViewTextBoxColumn();
                infoCol.Name = "colInfo";
                infoCol.HeaderText = "";
                infoCol.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                dataGridView1.Columns.Add(infoCol);
            }
            dataGridView1.Columns["colInfo"].DisplayIndex = 1;
            dataGridView1.Columns["colInfo"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            // Исходные колонки скрываются, данные выводятся в colInfo
            string[] hideCols = { "WorkerFIO", "WorkerPhone", "WorkerPassport", "WorkerLogin" };
            foreach (string col in hideCols)
                if (dataGridView1.Columns[col] != null) dataGridView1.Columns[col].Visible = false;

            // Видимая колонка с должностью (ролью сотрудника)
            if (dataGridView1.Columns["RoleName"] != null)
            {
                dataGridView1.Columns["RoleName"].HeaderText = "Должность";
                dataGridView1.Columns["RoleName"].Width = 120;
                dataGridView1.Columns["RoleName"].DisplayIndex = 2;
            }

            dataGridView1.ColumnHeadersVisible = false;
            dataGridView1.RowTemplate.Height = 80;

            // Формирование карточки сотрудника с маскированием персональных данных (152-ФЗ)
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                string fio = GetCellValue(row, "WorkerFIO");
                string phone = GetCellValue(row, "WorkerPhone");
                string passport = GetCellValue(row, "WorkerPassport");
                string login = GetCellValue(row, "WorkerLogin");

                // Маскирование телефона и паспорта звездочками
                string maskedPhone = MaskPhone(phone);
                string maskedPassport = MaskPassport(passport);

                row.Cells["colInfo"].Value = "ФИО: " + fio + Environment.NewLine
                    + "Телефон: " + maskedPhone + Environment.NewLine
                    + "Паспорт: " + maskedPassport + Environment.NewLine
                    + "Логин: " + login;
            }
        }

        // Безопасное получение значения ячейки в виде строки
        private string GetCellValue(DataGridViewRow row, string colName)
        {
            if (dataGridView1.Columns[colName] == null) return "";
            object v = row.Cells[colName].Value;
            return v == null || v == DBNull.Value ? "" : v.ToString();
        }

        // Маскирование номера телефона
        private string MaskPhone(string phone)
        {
            if (string.IsNullOrEmpty(phone) || phone.Length < 10)
                return "+7 (***) ***-**-**";
            return "+7 (***) ***-**-**";
        }

        // Маскирование номера паспорта
        private string MaskPassport(string passport)
        {
            if (string.IsNullOrEmpty(passport))
                return "**** ** *****";
            return "**** ** *****";
        }

        // Подстановка изображения пользователя
        private void ApplyImages()
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                row.Cells["colPhoto"].Value = GetUserImage();
            }
        }

        // Загрузка изображения пользователя
        private Image GetUserImage()
        {
            string fileName = "user.png";
            string folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
                                         "Resources", "images");
            string path = Path.Combine(folder, fileName);

            // Проверка существования файла перед отображением
            Image img;
            try
            {
                if (File.Exists(path))
                {
                    using (MemoryStream ms = new MemoryStream(File.ReadAllBytes(path)))
                        img = new Bitmap(Image.FromStream(ms));
                }
                else
                {
                    img = new Bitmap(60, 60);
                }
            }
            catch
            {
                img = new Bitmap(60, 60);
            }
            return img;
        }

        // Отрисовка кнопок пагинации
        private void RenderPagination(int pages)
        {
            var flow = this.Controls.Find("flowPagination", false);
            if (flow.Length == 0) return;
            FlowLayoutPanel flp = (FlowLayoutPanel)flow[0];
            flp.Controls.Clear();

            // Кнопка перехода на первую страницу
            Button btnFirst = CreateNavButton("|◀", currentPage > 1);
            btnFirst.Click += (s, ev) => { currentPage = 1; RefreshGrid(); };
            flp.Controls.Add(btnFirst);

            // Кнопка перехода на предыдущую страницу
            Button btnPrev = CreateNavButton("◀", currentPage > 1);
            btnPrev.Click += (s, ev) => { if (currentPage > 1) { currentPage--; RefreshGrid(); } };
            flp.Controls.Add(btnPrev);

            // Кнопки с номерами всех страниц, текущая выделяется цветом
            for (int i = 1; i <= pages; i++)
            {
                Button btn = new Button();
                btn.Text = i.ToString();
                btn.Size = new Size(35, 28);
                btn.FlatStyle = FlatStyle.Flat;
                btn.Margin = new Padding(2);
                if (i == currentPage)
                {
                    // Текущая страница выделяется оранжевым фоном
                    btn.Enabled = true;
                    btn.BackColor = Color.FromArgb(204, 102, 0);
                    btn.ForeColor = Color.White;
                }
                else
                {
                    btn.Enabled = true;
                    btn.BackColor = Color.White;
                    btn.ForeColor = Color.Black;
                }
                int page = i;
                btn.Click += (s, ev) => { currentPage = page; RefreshGrid(); };
                flp.Controls.Add(btn);
            }

            // Кнопка перехода на следующую страницу
            Button btnNext = CreateNavButton("▶", currentPage < pages);
            btnNext.Click += (s, ev) => { if (currentPage < totalPages) { currentPage++; RefreshGrid(); } };
            flp.Controls.Add(btnNext);

            // Кнопка перехода на последнюю страницу
            Button btnLast = CreateNavButton("▶|", currentPage < pages);
            btnLast.Click += (s, ev) => { currentPage = totalPages; RefreshGrid(); };
            flp.Controls.Add(btnLast);
        }

        // Создание навигационной кнопки пагинации
        private Button CreateNavButton(string text, bool enabled)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.Size = new Size(40, 28);
            btn.FlatStyle = FlatStyle.Flat;
            btn.Margin = new Padding(2);
            btn.Enabled = enabled;
            btn.BackColor = enabled ? Color.White : Color.FromArgb(240, 240, 240);
            btn.ForeColor = Color.Black;
            return btn;
        }

        private void returnbut_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
