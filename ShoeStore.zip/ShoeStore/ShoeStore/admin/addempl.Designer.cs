﻿
namespace ShoeStore.admin
{
    partial class addempl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addempl));
            this.returnbut = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.FIOtb = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.phonetb = new System.Windows.Forms.MaskedTextBox();
            this.passporttb = new System.Windows.Forms.MaskedTextBox();
            this.addbut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // returnbut
            // 
            this.returnbut.Location = new System.Drawing.Point(350, 220);
            this.returnbut.Name = "returnbut";
            this.returnbut.Size = new System.Drawing.Size(94, 33);
            this.returnbut.TabIndex = 1;
            this.returnbut.Text = "Назад";
            this.returnbut.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "ФИО";
            // 
            // FIOtb
            // 
            this.FIOtb.Location = new System.Drawing.Point(12, 32);
            this.FIOtb.MaxLength = 100;
            this.FIOtb.Name = "FIOtb";
            this.FIOtb.Size = new System.Drawing.Size(195, 26);
            this.FIOtb.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(238, 32);
            this.textBox2.MaxLength = 50;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(195, 26);
            this.textBox2.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(238, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Логин";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(238, 93);
            this.textBox3.MaxLength = 200;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(195, 26);
            this.textBox3.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(238, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Пароль";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "Телефон";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Паспорт";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(238, 154);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(195, 28);
            this.comboBox1.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(238, 131);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 20);
            this.label6.TabIndex = 13;
            this.label6.Text = "Роль";
            // 
            // phonetb
            // 
            this.phonetb.Location = new System.Drawing.Point(12, 93);
            this.phonetb.Mask = "00000000000";
            this.phonetb.Name = "phonetb";
            this.phonetb.Size = new System.Drawing.Size(195, 26);
            this.phonetb.TabIndex = 14;
            // 
            // passporttb
            // 
            this.passporttb.Location = new System.Drawing.Point(12, 154);
            this.passporttb.Mask = "0000 000000";
            this.passporttb.Name = "passporttb";
            this.passporttb.Size = new System.Drawing.Size(195, 26);
            this.passporttb.TabIndex = 15;
            // 
            // addbut
            // 
            this.addbut.Location = new System.Drawing.Point(12, 202);
            this.addbut.Name = "addbut";
            this.addbut.Size = new System.Drawing.Size(158, 40);
            this.addbut.TabIndex = 16;
            this.addbut.Text = "Добавить";
            this.addbut.UseVisualStyleBackColor = true;
            // 
            // addempl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(445, 254);
            this.Controls.Add(this.addbut);
            this.Controls.Add(this.passporttb);
            this.Controls.Add(this.phonetb);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.FIOtb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.returnbut);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "addempl";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Добавить сотрудника";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button returnbut;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox FIOtb;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox phonetb;
        private System.Windows.Forms.MaskedTextBox passporttb;
        private System.Windows.Forms.Button addbut;
    }
}