﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeStore.admin
{
    public partial class redactempl : Form
    {
        public redactempl()
        {
            InitializeComponent();
        }
    }
}
