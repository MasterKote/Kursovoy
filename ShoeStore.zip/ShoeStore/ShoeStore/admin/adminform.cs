﻿using MySql.Data.MySqlClient;
using ShoeStore.admin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeStore
{
    public partial class adminform : Form
    {
        private int workerId;
        private string conStr = "server=localhost;uid=root;database=shoestore_db;pwd=root;";

        public adminform(int workerId)
        {
            InitializeComponent();
            this.workerId = workerId;
            this.Load += adminform_Load;
        }

        private void adminform_Load(object sender, EventArgs e)
        {
            LoadWorkerInfo();
        }

        private void LoadWorkerInfo()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(conStr))
                {
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand(
                        "SELECT WorkerFIO FROM worker WHERE WorkerId = @id", con);
                    cmd.Parameters.AddWithValue("@id", workerId);
                    object fio = cmd.ExecuteScalar();
                    if (fio != null)
                        label2.Text = fio.ToString();
                }
            }
            catch { }
        }

        private void dbbut_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            admindbform form = new admindbform();
            form.ShowDialog();
            this.Visible = true;
        }

        private void employesbut_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            employesadminform form = new employesadminform();
            form.ShowDialog();
            this.Visible = true;
        }

        private void depotbut_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            depotform form = new depotform();
            form.ShowDialog();
            this.Visible = true;
        }

        private void exitbut_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
