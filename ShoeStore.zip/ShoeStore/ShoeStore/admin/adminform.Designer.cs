﻿
namespace ShoeStore
{
    partial class adminform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitbut = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dbbut = new System.Windows.Forms.Button();
            this.employesbut = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.depotbut = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // exitbut
            // 
            this.exitbut.Location = new System.Drawing.Point(322, 378);
            this.exitbut.Name = "exitbut";
            this.exitbut.Size = new System.Drawing.Size(87, 33);
            this.exitbut.TabIndex = 0;
            this.exitbut.Text = "Выход";
            this.exitbut.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ShoeStore.Properties.Resources.icons8_кроссовки_100;
            this.pictureBox1.Location = new System.Drawing.Point(155, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // dbbut
            // 
            this.dbbut.Location = new System.Drawing.Point(102, 200);
            this.dbbut.Name = "dbbut";
            this.dbbut.Size = new System.Drawing.Size(208, 50);
            this.dbbut.TabIndex = 2;
            this.dbbut.Text = "Управление БД";
            this.dbbut.UseVisualStyleBackColor = true;
            // 
            // employesbut
            // 
            this.employesbut.Location = new System.Drawing.Point(102, 255);
            this.employesbut.Name = "employesbut";
            this.employesbut.Size = new System.Drawing.Size(208, 50);
            this.employesbut.TabIndex = 3;
            this.employesbut.Text = "Сотрудники";
            this.employesbut.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(129, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Добро пожаловать,";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(115, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Иванов Иван Иванович";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // depotbut
            // 
            this.depotbut.Location = new System.Drawing.Point(101, 310);
            this.depotbut.Name = "depotbut";
            this.depotbut.Size = new System.Drawing.Size(208, 50);
            this.depotbut.TabIndex = 6;
            this.depotbut.Text = "Склад";
            this.depotbut.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(97, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(222, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Ваша роль: Администратор";
            // 
            // adminform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(411, 413);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.depotbut);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.employesbut);
            this.Controls.Add(this.dbbut);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.exitbut);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "adminform";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitbut;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button dbbut;
        private System.Windows.Forms.Button employesbut;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button depotbut;
        private System.Windows.Forms.Label label3;
    }
}