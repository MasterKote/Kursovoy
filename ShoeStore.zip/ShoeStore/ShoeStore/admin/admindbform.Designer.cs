﻿
namespace ShoeStore
{
    partial class admindbform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(admindbform));
            this.returnbut = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.fileimportbut = new System.Windows.Forms.Button();
            this.importbut = new System.Windows.Forms.Button();
            this.exportbut = new System.Windows.Forms.Button();
            this.fileexportbut = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // returnbut
            // 
            this.returnbut.Location = new System.Drawing.Point(206, 285);
            this.returnbut.Name = "returnbut";
            this.returnbut.Size = new System.Drawing.Size(87, 35);
            this.returnbut.TabIndex = 0;
            this.returnbut.Text = "Назад";
            this.returnbut.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(12, 33);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(277, 28);
            this.comboBox1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Таблица для импорта:";
            // 
            // fileimportbut
            // 
            this.fileimportbut.Location = new System.Drawing.Point(12, 67);
            this.fileimportbut.Name = "fileimportbut";
            this.fileimportbut.Size = new System.Drawing.Size(131, 36);
            this.fileimportbut.TabIndex = 3;
            this.fileimportbut.Text = "Выбрать файл";
            this.fileimportbut.UseVisualStyleBackColor = true;
            // 
            // importbut
            // 
            this.importbut.Location = new System.Drawing.Point(145, 67);
            this.importbut.Name = "importbut";
            this.importbut.Size = new System.Drawing.Size(144, 36);
            this.importbut.TabIndex = 4;
            this.importbut.Text = "Импортировать";
            this.importbut.UseVisualStyleBackColor = true;
            // 
            // exportbut
            // 
            this.exportbut.Location = new System.Drawing.Point(143, 182);
            this.exportbut.Name = "exportbut";
            this.exportbut.Size = new System.Drawing.Size(146, 36);
            this.exportbut.TabIndex = 8;
            this.exportbut.Text = "Экспортировать";
            this.exportbut.UseVisualStyleBackColor = true;
            // 
            // fileexportbut
            // 
            this.fileexportbut.Location = new System.Drawing.Point(12, 182);
            this.fileexportbut.Name = "fileexportbut";
            this.fileexportbut.Size = new System.Drawing.Size(131, 36);
            this.fileexportbut.TabIndex = 7;
            this.fileexportbut.Text = "Выбрать файл";
            this.fileexportbut.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Таблица для экспорта:";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(12, 148);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(277, 28);
            this.comboBox2.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 229);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 50);
            this.button1.TabIndex = 9;
            this.button1.Text = "Резервное копирование";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(149, 229);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(140, 50);
            this.button2.TabIndex = 10;
            this.button2.Text = "Восстановить структуру БД";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // admindbform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(295, 322);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.exportbut);
            this.Controls.Add(this.fileexportbut);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.importbut);
            this.Controls.Add(this.fileimportbut);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.returnbut);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "admindbform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Управление БД";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button returnbut;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button fileimportbut;
        private System.Windows.Forms.Button importbut;
        private System.Windows.Forms.Button exportbut;
        private System.Windows.Forms.Button fileexportbut;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}