﻿using MySql.Data.MySqlClient;
using ShoeStore.manager;
using ShoeStore.seller;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeStore
{
    public partial class Signinform : Form
    {
        string conStr = "server=localhost;uid=root;database=shoestore_db;pwd=root;";
        string captchaAnswer = "";
        Random rand = new Random();
        int captchaTime = 10;
        public Signinform()
        {
            InitializeComponent();
        }

        private void ShowCaptcha()
        {
            int number = rand.Next(1, 4);

            if (number == 1)
            {
                pictureBox2.Image = Image.FromFile("Resources/captcha/captcha1.png");
                captchaAnswer = "ed5YH7";
            }
            else if (number == 2)
            {
                pictureBox2.Image = Image.FromFile("Resources/captcha/captcha2.png");
                captchaAnswer = "9GjO3P";
            }
            else
            {
                pictureBox2.Image = Image.FromFile("Resources/captcha/captcha3.png");
                captchaAnswer = "HELL0O";
            }

            pictureBox2.Visible = true;
            textBox3.Visible = true;
            pictureBox3.Visible = true;

            textBox3.Clear();
        }

        private void signinbut_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text.Trim();
            string password = textBox2.Text.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Введите логин и пароль", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (textBox3.Visible)
            {
                if (textBox3.Text != captchaAnswer)
                {
                    MessageBox.Show("Неверная капча", "Ошибка",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);

                    signinbut.Enabled = false;
                    captchaTime = 10;
                    timer1.Start();

                    return;
                }
            }

            try
            {
                MySqlConnection con = new MySqlConnection(conStr);
                con.Open();

                string command = @"SELECT w.WorkerId, w.WorkerFIO, r.RoleName FROM worker w JOIN role r ON w.WorkerRole = r.RoleId WHERE w.WorkerLogin = @login AND w.WorkerPassword = @password";

                MySqlCommand cmd = new MySqlCommand(command, con);
                cmd.Parameters.AddWithValue("@login", login);
                cmd.Parameters.AddWithValue("@password", password);

                MySqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    int workerId = reader.GetInt32("WorkerId");
                    string role = reader.GetString("RoleName");

                    if (role == "Администратор")
                    {
                        this.Visible = false;
                        adminform form = new adminform(workerId);
                        form.ShowDialog();
                        this.Visible = true;
                    }
                    else if (role == "Менеджер")
                    {
                        this.Visible = false;
                        managerform form = new managerform(workerId);
                        form.ShowDialog();
                        this.Visible = true;
                    }
                    else if (role == "Продавец")
                    {
                        this.Visible = false;
                        sellerform form = new sellerform(workerId);
                        form.ShowDialog();
                        this.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show("Неизвестная роль: " + role);
                    }

                    reader.Close();
                    con.Close();
                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль", "Ошибка авторизации",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);

                    reader.Close();
                    con.Close();
                    ShowCaptcha();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения к базе данных: " + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void exitbut_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        { 
            ShowCaptcha();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            captchaTime--;

            if (captchaTime <= 0)
            {
                timer1.Stop();
                signinbut.Enabled = true;
                ShowCaptcha();
            }
        }
    }
}
