﻿using MySql.Data.MySqlClient;
using ShoeStore.admin;
using ShoeStore.shared;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeStore.manager
{
    public partial class managerform : Form
    {
        private int workerId;
        private string conStr = "server=localhost;uid=root;database=shoestore_db;pwd=root;";

        public managerform(int workerId)
        {
            InitializeComponent();
            this.workerId = workerId;
            this.Load += managerform_Load;
        }

        private void managerform_Load(object sender, EventArgs e)
        {
            LoadWorkerInfo();
        }

        private void LoadWorkerInfo()
        {
            try
            {
                using (MySqlConnection con = new MySqlConnection(conStr))
                {
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand(
                        "SELECT WorkerFIO FROM worker WHERE WorkerId = @id", con);
                    cmd.Parameters.AddWithValue("@id", workerId);
                    object fio = cmd.ExecuteScalar();
                    if (fio != null)
                        label2.Text = fio.ToString();
                }
            }
            catch { }
        }

        private void ordersbut_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            ordersform form = new ordersform();
            form.ShowDialog();
            this.Visible = true;
        }

        private void clientsbut_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            clientsform form = new clientsform();
            form.ShowDialog();
            this.Visible = true;
        }

        private void depotbut_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            depotform form = new depotform();
            form.ShowDialog();
            this.Visible = true;
        }

        private void exitbut_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
