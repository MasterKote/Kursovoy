﻿
namespace ShoeStore.manager
{
    partial class clientsmanagerform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(clientsmanagerform));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.returnbut = new System.Windows.Forms.Button();
            this.delbut = new System.Windows.Forms.Button();
            this.redactbut = new System.Windows.Forms.Button();
            this.addbut = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(686, 249);
            this.dataGridView1.TabIndex = 0;
            // 
            // returnbut
            // 
            this.returnbut.Location = new System.Drawing.Point(605, 392);
            this.returnbut.Name = "returnbut";
            this.returnbut.Size = new System.Drawing.Size(81, 28);
            this.returnbut.TabIndex = 1;
            this.returnbut.Text = "Назад";
            this.returnbut.UseVisualStyleBackColor = true;
            // 
            // delbut
            // 
            this.delbut.Enabled = false;
            this.delbut.Location = new System.Drawing.Point(12, 361);
            this.delbut.Name = "delbut";
            this.delbut.Size = new System.Drawing.Size(132, 47);
            this.delbut.TabIndex = 2;
            this.delbut.Text = "Удалить";
            this.delbut.UseVisualStyleBackColor = true;
            // 
            // redactbut
            // 
            this.redactbut.Enabled = false;
            this.redactbut.Location = new System.Drawing.Point(12, 308);
            this.redactbut.Name = "redactbut";
            this.redactbut.Size = new System.Drawing.Size(132, 47);
            this.redactbut.TabIndex = 3;
            this.redactbut.Text = "Изменить";
            this.redactbut.UseVisualStyleBackColor = true;
            // 
            // addbut
            // 
            this.addbut.Location = new System.Drawing.Point(12, 255);
            this.addbut.Name = "addbut";
            this.addbut.Size = new System.Drawing.Size(132, 47);
            this.addbut.TabIndex = 4;
            this.addbut.Text = "Добавить";
            this.addbut.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(172, 255);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "ФИО клиента";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(167, 338);
            this.maskedTextBox1.Mask = "00000000000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(290, 26);
            this.maskedTextBox1.TabIndex = 6;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(167, 276);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(290, 26);
            this.textBox1.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(172, 315);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Номер телефона";
            // 
            // clientsmanagerform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 420);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.addbut);
            this.Controls.Add(this.redactbut);
            this.Controls.Add(this.delbut);
            this.Controls.Add(this.returnbut);
            this.Controls.Add(this.dataGridView1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "clientsmanagerform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Клиенты";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button returnbut;
        private System.Windows.Forms.Button delbut;
        private System.Windows.Forms.Button redactbut;
        private System.Windows.Forms.Button addbut;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
    }
}