﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoeStore.manager
{
    public partial class clientsmanagerform : Form
    {
        public clientsmanagerform()
        {
            InitializeComponent();
        }
    }
}
