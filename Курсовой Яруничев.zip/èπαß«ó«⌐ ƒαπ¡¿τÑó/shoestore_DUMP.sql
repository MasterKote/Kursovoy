CREATE DATABASE  IF NOT EXISTS `shoestore_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `shoestore_db`;
-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: shoestore_db
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `brand`
--

DROP TABLE IF EXISTS `brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brand` (
  `BrandId` int NOT NULL AUTO_INCREMENT,
  `BrandName` varchar(100) NOT NULL,
  PRIMARY KEY (`BrandId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brand`
--

LOCK TABLES `brand` WRITE;
/*!40000 ALTER TABLE `brand` DISABLE KEYS */;
INSERT INTO `brand` VALUES (1,'Nike'),(2,'Adidas'),(3,'Puma'),(4,'Reebok'),(5,'New Balance'),(6,'Asics'),(7,'Under Armour'),(8,'Converse'),(9,'Vans'),(10,'Timberland'),(11,'Dr. Martens'),(12,'Ecco'),(13,'Rieker'),(14,'Clarks'),(15,'Geox'),(16,'Lacoste'),(17,'Tommy Hilfiger'),(18,'Zenden'),(19,'Ralf Ringer'),(20,'Tamaris');
/*!40000 ALTER TABLE `brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoryshoes`
--

DROP TABLE IF EXISTS `categoryshoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoryshoes` (
  `CategoryShoesId` int NOT NULL AUTO_INCREMENT,
  `CategoryShoesName` varchar(50) NOT NULL,
  PRIMARY KEY (`CategoryShoesId`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoryshoes`
--

LOCK TABLES `categoryshoes` WRITE;
/*!40000 ALTER TABLE `categoryshoes` DISABLE KEYS */;
INSERT INTO `categoryshoes` VALUES (1,'Кроссовки'),(2,'Кеды'),(3,'Туфли'),(4,'Ботинки'),(5,'Сапоги'),(6,'Полусапоги'),(7,'Сандалии'),(8,'Сланцы и шлепанцы'),(9,'Мокасины и лоферы'),(10,'Балетки'),(11,'Ботильоны'),(12,'Домашняя обувь'),(13,'Спортивная специализированная (бутсы, трекинг)'),(14,'Резиновые сапоги'),(15,'Унты и угги');
/*!40000 ALTER TABLE `categoryshoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client` (
  `ClientId` int NOT NULL AUTO_INCREMENT,
  `ClientFIO` varchar(100) NOT NULL,
  `ClientPhone` varchar(20) NOT NULL,
  PRIMARY KEY (`ClientId`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,'Иванов Александр Сергеевич','+7 (910) 123-45-67'),(2,'Петрова Елена Владимировна','+7 (920) 234-56-78'),(3,'Смирнов Дмитрий Николаевич','+7 (930) 345-67-89'),(4,'Кузнецова Ольга Игоревна','+7 (950) 456-78-90'),(5,'Попов Алексей Андреевич','+7 (960) 567-89-01'),(6,'Васильева Наталья Викторовна','+7 (999) 678-90-12'),(7,'Соколов Максим Олегович','+7 (903) 789-01-23'),(8,'Михайлова Анна Дмитриевна','+7 (905) 890-12-34'),(9,'Новиков Артем Петрович','+7 (906) 901-23-45'),(10,'Федорова Мария Александровна','+7 (909) 012-34-56'),(11,'Морозов Илья Васильевич','+7 (911) 111-22-33'),(12,'Волкова Светлана Юрьевна','+7 (912) 222-33-44'),(13,'Алексеев Денис Михайлович','+7 (915) 333-44-55'),(14,'Лебедева Татьяна Евгеньевна','+7 (916) 444-55-66'),(15,'Семенов Егор Павлович','+7 (917) 555-66-77'),(16,'Егорова Юлия Сергеевна','+7 (919) 666-77-88'),(17,'Павлов Роман Антонович','+7 (921) 777-88-99'),(18,'Козлова Анастасия Алексеевна','+7 (922) 888-99-00'),(19,'Степанов Владислав Игоревич','+7 (925) 999-00-11'),(20,'Николаева Екатерина Олеговна','+7 (926) 123-98-76'),(21,'Орлов Никита Константинович','+7 (929) 234-87-65'),(22,'Андреева Дарья Валерьевна','+7 (931) 345-76-54'),(23,'Макаров Кирилл Геннадьевич','+7 (932) 456-65-43'),(24,'Никитина Марина Анатольевна','+7 (936) 567-54-32'),(25,'Захаров Богдан Русланович','+7 (941) 678-43-21'),(26,'Зайцева Ирина Витальевна','+7 (951) 789-32-10'),(27,'Соловьев Тимофей Аркадьевич','+7 (952) 890-21-09'),(28,'Борисова Ксения Эдуардовна','+7 (953) 901-10-98'),(29,'Яковлев Даниил Вадимович','+7 (961) 012-09-87'),(30,'Григорьева Алина Маратовна','+7 (962) 123-11-22'),(31,'Романов Матвей Филиппович','+7 (963) 234-22-33'),(32,'Воробьева Кира Львовна','+7 (964) 345-33-44'),(33,'Сергеев Арсений Денисович','+7 (965) 456-44-55'),(34,'Кудрявцева Вероника Романовна','+7 (966) 567-55-66'),(35,'Кузьмин Павел Артурович','+7 (967) 678-66-77'),(36,'Александрова Полина Ильинична','+7 (968) 789-77-88'),(37,'Фролов Глеб Станиславович','+7 (977) 890-88-99'),(38,'Королева Ева Тимуровна','+7 (981) 901-99-00'),(39,'Пономарев Марк Георгиевич','+7 (982) 012-00-11'),(40,'Попова Милана Давидовна','+7 (985) 123-44-11'),(41,'Королев Лев Савельевич','+7 (986) 234-55-22'),(42,'Киселева Василиса Максимовна','+7 (987) 345-66-33'),(43,'Макарова Ангелина Петровна','+7 (988) 456-77-44'),(44,'Ковалев Тимур Борисович','+7 (989) 567-88-55'),(45,'Ильина Кристина Егоровна','+7 (991) 678-99-66'),(46,'Гусев Дамир Федорович','+7 (992) 789-00-77'),(47,'Титова Алена Святославовна','+7 (993) 890-11-88'),(48,'Козлов Иван Михайлович','+7 (994) 901-22-99'),(49,'Фомина Диана Викторовна','+7 (995) 012-33-00'),(50,'Кудрявцев Савва Антонович','+7 (996) 123-55-66');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offersshoes`
--

DROP TABLE IF EXISTS `offersshoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offersshoes` (
  `OffersShoesId` int NOT NULL AUTO_INCREMENT,
  `OffersShoesName` varchar(50) NOT NULL,
  `OffersShoesDiscount` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`OffersShoesId`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offersshoes`
--

LOCK TABLES `offersshoes` WRITE;
/*!40000 ALTER TABLE `offersshoes` DISABLE KEYS */;
INSERT INTO `offersshoes` VALUES (1,'Без скидки',0),(2,'Сезонная распродажа',10),(3,'Зимняя ликвидация',25),(4,'Летний бум',15),(5,'Черная пятница',30),(6,'Киберпонедельник',20),(7,'Скидка именинника',12),(8,'Студенческий дисконт',5),(9,'Второй товар в чеке',15),(10,'Финальная цена',40),(11,'Новогодняя сказка',22),(12,'Первая покупка',7),(13,'Ликвидация коллекции',50),(14,'Весеннее обновление',18),(15,'День бренда',13);
/*!40000 ALTER TABLE `offersshoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order` (
  `OrderId` int NOT NULL AUTO_INCREMENT,
  `WorkerId` int NOT NULL,
  `ClientId` int NOT NULL,
  `OrderDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `OrderPrice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `OrderStatus` enum('Ожидание','В процессе','Выполнен','Отменён') NOT NULL DEFAULT 'Ожидание',
  `OrderStatusPayment` enum('Не оплачен','Оплачен','Возврат') NOT NULL DEFAULT 'Не оплачен',
  PRIMARY KEY (`OrderId`),
  KEY `WorkerId` (`WorkerId`),
  KEY `ClientId` (`ClientId`),
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`WorkerId`) REFERENCES `worker` (`WorkerId`),
  CONSTRAINT `order_ibfk_2` FOREIGN KEY (`ClientId`) REFERENCES `client` (`ClientId`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,11,1,'2026-09-01 10:15:00',17980.00,'Выполнен','Оплачен'),(2,12,2,'2026-09-01 12:30:00',16500.00,'Выполнен','Оплачен'),(3,13,3,'2026-09-02 14:45:00',21990.00,'Выполнен','Оплачен'),(4,14,4,'2026-09-02 17:10:00',14980.00,'Выполнен','Оплачен'),(5,15,5,'2026-09-03 11:05:00',19990.00,'Отменён','Не оплачен'),(6,16,6,'2026-09-03 15:20:00',13990.00,'Выполнен','Оплачен'),(7,17,7,'2026-09-04 18:40:00',11990.00,'Выполнен','Оплачен'),(8,18,8,'2026-09-04 19:15:00',6990.00,'Выполнен','Оплачен'),(9,19,9,'2026-09-05 10:00:00',9490.00,'Выполнен','Оплачен'),(10,20,10,'2026-09-05 13:50:00',9990.00,'Выполнен','Оплачен'),(11,21,11,'2026-09-06 12:15:00',21480.00,'Выполнен','Оплачен'),(12,22,12,'2026-09-07 14:30:00',7990.00,'Выполнен','Оплачен'),(13,23,13,'2026-09-07 16:45:00',15490.00,'Выполнен','Оплачен'),(14,24,14,'2026-09-08 11:20:00',8490.00,'Отменён','Не оплачен'),(15,25,15,'2026-09-09 15:10:00',13200.00,'Выполнен','Оплачен'),(16,26,16,'2026-09-09 17:35:00',17990.00,'Выполнен','Оплачен'),(17,27,17,'2026-09-10 10:45:00',14980.00,'Выполнен','Оплачен'),(18,28,18,'2026-09-10 13:15:00',16990.00,'Выполнен','Оплачен'),(19,29,19,'2026-09-11 14:00:00',10980.00,'Выполнен','Оплачен'),(20,30,20,'2026-09-11 16:50:00',9490.00,'Выполнен','Оплачен'),(21,31,21,'2026-09-12 11:10:00',13990.00,'Выполнен','Оплачен'),(22,32,22,'2026-09-12 15:30:00',6290.00,'Выполнен','Оплачен'),(23,33,23,'2026-09-13 18:20:00',12490.00,'Выполнен','Оплачен'),(24,34,24,'2026-09-14 12:40:00',19980.00,'Выполнен','Оплачен'),(25,35,25,'2026-09-15 10:15:00',11200.00,'Выполнен','Оплачен'),(26,36,26,'2026-09-15 14:55:00',16500.00,'Выполнен','Оплачен'),(27,37,27,'2026-09-16 16:30:00',8990.00,'Выполнен','Оплачен'),(28,38,28,'2026-09-17 11:00:00',21990.00,'Выполнен','Возврат'),(29,39,29,'2026-09-17 13:45:00',13990.00,'Выполнен','Оплачен'),(30,40,30,'2026-09-18 15:20:00',19990.00,'Выполнен','Оплачен'),(31,41,31,'2026-09-19 17:10:00',17970.00,'Выполнен','Оплачен'),(32,42,32,'2026-09-20 10:30:00',10990.00,'Выполнен','Оплачен'),(33,43,33,'2026-09-21 12:00:00',12990.00,'Выполнен','Оплачен'),(34,44,34,'2026-09-21 14:50:00',5990.00,'Выполнен','Оплачен'),(35,45,35,'2026-09-22 16:15:00',3290.00,'Выполнен','Оплачен'),(36,46,36,'2026-09-22 18:35:00',11490.00,'Выполнен','Оплачен'),(37,47,37,'2026-09-23 11:40:00',15990.00,'Выполнен','Оплачен'),(38,48,38,'2026-09-23 13:10:00',10990.00,'Выполнен','Оплачен'),(39,49,39,'2026-09-24 15:00:00',12990.00,'Выполнен','Оплачен'),(40,50,40,'2026-09-24 17:25:00',19980.00,'Выполнен','Оплачен'),(41,11,41,'2026-09-25 10:50:00',8990.00,'Выполнен','Оплачен'),(42,12,42,'2026-09-25 14:15:00',14500.00,'Выполнен','Оплачен'),(43,13,43,'2026-09-26 16:00:00',7290.00,'Выполнен','Оплачен'),(44,14,44,'2026-09-27 12:30:00',6490.00,'В процессе','Не оплачен'),(45,15,45,'2026-09-27 15:10:00',12990.00,'В процессе','Оплачен'),(46,16,46,'2026-09-28 11:00:00',14990.00,'Ожидание','Не оплачен'),(47,17,47,'2026-09-28 13:40:00',21990.00,'Ожидание','Не оплачен'),(48,18,48,'2026-09-29 10:15:00',13990.00,'Ожидание','Не оплачен'),(49,19,49,'2026-09-29 11:30:00',6990.00,'Ожидание','Не оплачен'),(50,20,50,'2026-09-29 12:45:00',16500.00,'Ожидание','Не оплачен');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderitems`
--

DROP TABLE IF EXISTS `orderitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orderitems` (
  `OrderItemId` int NOT NULL AUTO_INCREMENT,
  `OrderId` int NOT NULL,
  `ShoesId` int NOT NULL,
  `ShoesCount` int NOT NULL DEFAULT '1',
  `PriceAtPurchase` decimal(10,2) NOT NULL,
  PRIMARY KEY (`OrderItemId`),
  KEY `OrderId` (`OrderId`),
  KEY `ShoesId` (`ShoesId`),
  CONSTRAINT `orderitems_ibfk_1` FOREIGN KEY (`OrderId`) REFERENCES `order` (`OrderId`) ON DELETE CASCADE,
  CONSTRAINT `orderitems_ibfk_2` FOREIGN KEY (`ShoesId`) REFERENCES `shoes` (`ShoesId`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderitems`
--

LOCK TABLES `orderitems` WRITE;
/*!40000 ALTER TABLE `orderitems` DISABLE KEYS */;
INSERT INTO `orderitems` VALUES (1,1,1,1,14990.00),(2,1,22,1,2990.00),(3,2,2,1,16500.00),(4,3,14,1,21990.00),(5,4,6,2,7490.00),(6,5,15,1,19990.00),(7,6,8,1,12500.00),(8,6,28,1,1490.00),(9,7,3,1,11990.00),(10,8,11,1,6990.00),(11,9,4,1,9490.00),(12,10,16,1,9990.00),(13,11,5,1,13990.00),(14,11,34,1,7490.00),(15,12,7,1,7990.00),(16,13,17,1,15490.00),(17,14,12,1,8490.00),(18,15,9,1,13200.00),(19,16,18,1,17990.00),(20,17,10,1,11490.00),(21,17,23,1,3490.00),(22,18,19,1,16990.00),(23,19,13,2,5490.00),(24,20,20,1,9490.00),(25,21,25,1,13990.00),(26,22,21,1,6290.00),(27,23,26,1,12490.00),(28,24,24,1,4990.00),(29,24,30,1,14990.00),(30,25,27,1,11200.00),(31,26,31,1,16500.00),(32,27,29,1,8990.00),(33,28,35,1,21990.00),(34,29,32,1,13990.00),(35,30,36,1,19990.00),(36,31,33,1,11990.00),(37,31,22,2,2990.00),(38,32,37,1,10990.00),(39,33,38,1,12990.00),(40,34,39,1,5990.00),(41,35,40,1,3290.00),(42,36,41,1,11490.00),(43,37,42,1,15990.00),(44,38,43,1,10990.00),(45,39,44,1,12990.00),(46,40,45,1,18490.00),(47,40,28,1,1490.00),(48,41,46,1,8990.00),(49,42,47,1,14500.00),(50,43,48,1,7290.00),(51,44,49,1,6490.00),(52,45,50,1,12990.00),(53,46,1,1,14990.00),(54,47,14,1,21990.00),(55,48,5,1,13990.00),(56,49,11,1,6990.00),(57,50,2,1,16500.00);
/*!40000 ALTER TABLE `orderitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `RoleId` int NOT NULL AUTO_INCREMENT,
  `RoleName` varchar(200) NOT NULL,
  PRIMARY KEY (`RoleId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Администратор'),(2,'Менеджер'),(3,'Продавец');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shoes`
--

DROP TABLE IF EXISTS `shoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shoes` (
  `ShoesId` int NOT NULL AUTO_INCREMENT,
  `ShoesName` varchar(100) NOT NULL,
  `ShoesDescription` text,
  `ShoesSize` decimal(3,1) NOT NULL,
  `ShoesColor` varchar(30) NOT NULL,
  `ShoesPrice` decimal(10,2) NOT NULL,
  `ShoesQuantity` int NOT NULL DEFAULT '0',
  `ShoesCategory` int NOT NULL,
  `BrandId` int NOT NULL,
  `OffersShoes` int NOT NULL,
  `ShoesPhoto` text,
  PRIMARY KEY (`ShoesId`),
  KEY `ShoesCategory` (`ShoesCategory`),
  KEY `BrandId` (`BrandId`),
  KEY `shoes_ibfk_3` (`OffersShoes`),
  CONSTRAINT `shoes_ibfk_1` FOREIGN KEY (`ShoesCategory`) REFERENCES `categoryshoes` (`CategoryShoesId`),
  CONSTRAINT `shoes_ibfk_2` FOREIGN KEY (`BrandId`) REFERENCES `brand` (`BrandId`),
  CONSTRAINT `shoes_ibfk_3` FOREIGN KEY (`OffersShoes`) REFERENCES `offersshoes` (`OffersShoesId`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shoes`
--

LOCK TABLES `shoes` WRITE;
/*!40000 ALTER TABLE `shoes` DISABLE KEYS */;
INSERT INTO `shoes` VALUES (1,'Nike Air Max 270','Легендарные беговые кроссовки с амортизирующей подушкой Max Air.',42.0,'Черный',14990.00,25,1,1,1,'/images/shoes/nike_air270_black.jpg'),(2,'Adidas Ultraboost 22','Спортивные кроссовки для интенсивного бега с подошвой Boost.',43.5,'Белый',16500.00,18,1,2,4,'/images/shoes/adidas_ub22_white.jpg'),(3,'Puma RS-X Triple','Массивные лайфстайл кроссовки в стиле ретро-футуризма.',41.0,'Серый',11990.00,14,1,3,1,'/images/shoes/puma_rsx_grey.jpg'),(4,'Reebok Classic Leather','Классические повседневные кроссовки из мягкой натуральной кожи.',40.0,'Белый',9490.00,30,1,4,2,'/images/shoes/reebok_classic_white.jpg'),(5,'New Balance 574','Универсальные городские кроссовки с узнаваемым силуэтом.',44.0,'Синий',13990.00,22,1,5,1,'/images/shoes/nb574_blue.jpg'),(6,'Converse Chuck Taylor All Star','Культовые высокие текстильные кеды.',38.0,'Черный',7490.00,45,2,8,8,'/images/shoes/converse_high_black.jpg'),(7,'Vans Old Skool','Классические скейт-кеды со знаменитой боковой полосой.',39.0,'Черно-белый',7990.00,40,2,9,1,'/images/shoes/vans_oldskool.jpg'),(8,'Clarks Leather Oxford','Строгие мужские туфли из премиальной кожи для деловых встреч.',42.0,'Коричневый',12500.00,12,3,14,1,'/images/shoes/clarks_oxford_brown.jpg'),(9,'Geox Сlassic Derby','Дышащие кожаные дерби на технологичной подошве.',43.0,'Черный',13200.00,15,3,15,7,'/images/shoes/geox_derby.jpg'),(10,'Ecco City Loafer','Комфортные мужские лоферы из мягкой перфорированной кожи.',41.0,'Темно-синий',11490.00,20,9,12,1,'/images/shoes/ecco_loafer.jpg'),(11,'Tamaris Leather Pumps','Женские элегантные туфли-лодочки на устойчивом каблуке.',37.0,'Бежевый',6990.00,17,3,20,14,'/images/shoes/tamaris_pumps.jpg'),(12,'Ralf Ringer Casual Loafers','Повседневные замшевые лоферы ручной прошивки.',42.5,'Серый',8490.00,19,9,19,2,'/images/shoes/ralf_loafer.jpg'),(13,'Tamaris Ballet Flats','Легкие женские балетки с анатомической стелькой Memory Foam.',36.0,'Черный',5490.00,25,10,20,1,'/images/shoes/tamaris_ballet.jpg'),(14,'Timberland 6-Inch Premium','Знаменитые водонепроницаемые рабочие ботинки.',41.5,'Желтый',21990.00,10,4,10,1,'/images/shoes/timberland_6inch.jpg'),(15,'Dr. Martens 1460 Smooth','Культовые ботинки на 8 люверсов с желтой прошивкой.',39.0,'Черный',19990.00,12,4,11,13,'/images/shoes/docs_1460.jpg'),(16,'Rieker Antistress Boot','Зимние ботинки на натуральной шерсти с системой защиты от скольжения.',44.0,'Черный',9990.00,35,4,13,3,'/images/shoes/rieker_winter.jpg'),(17,'Ecco Trace Boot','Теплые женские полусапоги с мембраной Gore-Tex.',38.0,'Белый',15490.00,14,6,12,1,'/images/shoes/ecco_trace.jpg'),(18,'Geox Winter Boots','Высокие мужские сапоги для экстремальных холодов.',45.0,'Коричневый',17990.00,8,5,15,3,'/images/shoes/geox_winter.jpg'),(19,'Tommy Hilfiger Suede Ankle','Стильные замшевые ботильоны на среднем каблуке.',37.5,'Бордовый',16990.00,11,11,17,5,'/images/shoes/th_ankle_boots.jpg'),(20,'Ecco Yucatan Sandal','Треккинговые сандалии с превосходной поддержкой стопы.',43.0,'Хаки',9490.00,24,7,12,4,'/images/shoes/ecco_yucatan.jpg'),(21,'Rieker Summer Sandal','Легкие женские летние сандалии на гибкой подошве.',38.0,'Синий',6290.00,30,7,13,1,'/images/shoes/rieker_sandal.jpg'),(22,'Nike Benassi JDI','Спортивные мужские шлепанцы для бассейна и пляжа.',42.0,'Черно-белый',2990.00,50,8,1,1,'/images/shoes/nike_benassi.jpg'),(23,'Adidas Adilette Slides','Анатомические сланцы с мягкой амортизацией.',41.0,'Синий',3490.00,45,8,2,8,'/images/shoes/adidas_adilette.jpg'),(24,'Lacoste Croco Slide','Премиальные летние шлепанцы с фирменным крокодилом.',43.0,'Зеленый',4990.00,20,8,16,1,'/images/shoes/lacoste_slide.jpg'),(25,'Adidas Predator Edge','Футбольные бутсы для игры на естественных жестких покрытиях.',42.5,'Красный',13990.00,15,13,2,6,'/images/shoes/adidas_predator.jpg'),(26,'Asics Gel-Trabuco','Кроссовки для трейлраннинга и бега по пересеченной местности.',44.0,'Черно-оранжевый',12490.00,16,13,6,1,'/images/shoes/asics_trabuco.jpg'),(27,'Hunter Original Tall','Водонепроницаемые резиновые сапоги ручной сборки.',38.0,'Глянцевый черный',11200.00,18,14,14,1,'/images/shoes/hunter_tall.jpg'),(28,'Zenden Home Slippers','Уютные домашние тапочки из плотного текстиля.',40.0,'Серый',1490.00,60,12,18,9,'/images/shoes/zenden_home.jpg'),(29,'Ralf Ringer Sheepskin Uggs','Женские угги из натуральной овчины, очень теплые.',37.0,'Серый',8990.00,12,15,19,11,'/images/shoes/ralf_uggs.jpg'),(30,'Nike Air Max 270 W','Женская версия культовых кроссовок Air Max.',36.5,'Розовый',14990.00,15,1,1,1,'/images/shoes/nike_air270_pink.jpg'),(31,'Adidas Ultraboost 22 M','Беговые кроссовки Ultraboost в практичном темном цвете.',45.0,'Черный',16500.00,20,1,2,1,'/images/shoes/adidas_ub22_black.jpg'),(32,'New Balance 574 W','Женские городские кроссовки нежной расцветки.',37.0,'Мятный',13990.00,18,1,5,15,'/images/shoes/nb574_mint.jpg'),(33,'Puma RS-X Neon','Кроссовки со стильными неоновыми вставками.',42.0,'Черно-желтый',11990.00,10,1,3,10,'/images/shoes/puma_rsx_neon.jpg'),(34,'Converse Chuck Taylor White','Низкие текстильные кеды, базовая летняя модель.',41.0,'Белый',7490.00,35,2,8,1,'/images/shoes/converse_low_white.jpg'),(35,'Timberland Black Premium','Зимние мужские ботинки премиум сегмента в черном цвете.',43.0,'Черный',21990.00,12,4,10,1,'/images/shoes/timberland_6inch_black.jpg'),(36,'Dr. Martens Cherry Red','Ботинки Docs из гладкой кожи глубокого вишневого цвета.',40.0,'Бордовый',19990.00,9,4,11,1,'/images/shoes/docs_cherry.jpg'),(37,'Clarks Desert Boots','Классические замшевые дезерты на креповой подошве.',42.0,'Песочный',10990.00,14,4,14,2,'/images/shoes/clarks_desert.jpg'),(38,'Ecco Soft 7 Sneaker','Кожаные полуботинки в стиле смарт-кэжуал.',43.0,'Белый',12990.00,22,1,12,1,'/images/shoes/ecco_soft7.jpg'),(39,'Rieker Summer Loafer','Женские перфорированные туфли без шнурков на лето.',39.0,'Белый',5990.00,28,9,13,4,'/images/shoes/rieker_loafer_white.jpg'),(40,'Zenden Rubber Boots','Практичные женские резиновые сапожки с ярким принтом.',38.0,'Разноцветный',3290.00,25,14,18,1,'/images/shoes/zenden_rubber.jpg'),(41,'Under Armour Hovr Sonic','Высокотехнологичные кроссовки с датчиком подключения к фитнес-трекеру.',43.0,'Красный',11490.00,15,1,7,1,'/images/shoes/ua_hovr.jpg'),(42,'Asics Gel-Kayano 29','Профессиональные беговые кроссовки с усиленной поддержкой стопы.',44.5,'Синий',15990.00,10,1,6,6,'/images/shoes/asics_kayano.jpg'),(43,'Lacoste Carnaby Evo','Кожаные минималистичные кеды с зеленым логотипом бренда.',41.0,'Белый',10990.00,16,2,16,1,'/images/shoes/lacoste_carnaby.jpg'),(44,'Tommy Hilfiger Corporate Leather','Стильные мужские кеды из натуральной плотной кожи.',42.0,'Темно-синий',12990.00,14,2,17,12,'/images/shoes/th_corporate.jpg'),(45,'Timberland Chuka Boot','Демисезонные укороченные ботинки из мягкого нубука.',42.5,'Светло-коричневый',18490.00,9,4,10,1,'/images/shoes/timberland_chuka.jpg'),(46,'Rieker Tex Waterproof','Осенние полусапоги с водонепроницаемой мембраной RiekerTex.',40.0,'Черный',8990.00,21,6,13,14,'/images/shoes/rieker_tex.jpg'),(47,'Geox Chelsea Boot','Кожаные ботинки челси с эластичными вставками по бокам.',43.0,'Черный',14500.00,11,4,15,1,'/images/shoes/geox_chelsea.jpg'),(48,'Tamaris Platform Sandals','Женские босоножки на массивной модной платформе.',37.0,'Черный',7290.00,18,7,20,2,'/images/shoes/tamaris_platform.jpg'),(49,'Zenden Winter Boots','Мужские зимние ботинки на толстой подошве с натуральным мехом.',43.5,'Коричневый',6490.00,30,4,18,3,'/images/shoes/zenden_winter.jpg'),(50,'Ralf Ringer High Boots','Классические женские кожаные сапоги на устойчивом каблуке.',38.0,'Черный',12990.00,13,5,19,1,'/images/shoes/ralf_high_boots.jpg');
/*!40000 ALTER TABLE `shoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker`
--

DROP TABLE IF EXISTS `worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worker` (
  `WorkerId` int NOT NULL AUTO_INCREMENT,
  `WorkerFIO` varchar(100) NOT NULL,
  `WorkerLogin` varchar(50) NOT NULL,
  `WorkerPassword` varchar(200) NOT NULL,
  `WorkerPhone` varchar(20) NOT NULL,
  `WorkerPassport` varchar(20) NOT NULL,
  `WorkerRole` int NOT NULL,
  PRIMARY KEY (`WorkerId`),
  UNIQUE KEY `WorkerLogin` (`WorkerLogin`),
  KEY `WorkerRole` (`WorkerRole`),
  CONSTRAINT `worker_ibfk_1` FOREIGN KEY (`WorkerRole`) REFERENCES `role` (`RoleId`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker`
--

LOCK TABLES `worker` WRITE;
/*!40000 ALTER TABLE `worker` DISABLE KEYS */;
INSERT INTO `worker` VALUES (1,'Попова Ольга Ильинична','worker_1','pwd_secure_101','+7 (999) 616-64-52','3646 879170',1),(2,'Кузьмин Кирилл Антонович','worker_2','pwd_secure_102','+7 (999) 988-30-91','8383 302705',1),(3,'Андреева Анна Витальевна','worker_3','pwd_secure_103','+7 (999) 905-55-77','2667 727643',1),(4,'Никитина Анна Петровна','worker_4','pwd_secure_104','+7 (999) 782-52-33','3446 273717',2),(5,'Королев Марк Вадимович','worker_5','pwd_secure_105','+7 (999) 227-16-53','5363 699098',2),(6,'Кузнецова Диана Тимуровна','worker_6','pwd_secure_106','+7 (999) 293-66-41','1291 751227',2),(7,'Павлов Павел Филиппович','worker_7','pwd_secure_107','+7 (999) 611-29-84','9575 598464',2),(8,'Кудрявцев Дамир Станиславович','worker_8','pwd_secure_108','+7 (999) 415-55-83','4531 382816',2),(9,'Кудрявцева Василиса Сергеевна','worker_9','pwd_secure_109','+7 (999) 492-78-97','3233 119805',2),(10,'Сергеев Илья Борисович','worker_10','pwd_secure_110','+7 (999) 542-10-15','3030 652946',2),(11,'Смирнов Максим Георгиевич','worker_11','pwd_secure_111','+7 (999) 225-27-67','7453 511982',3),(12,'Иванов Тимофей Федорович','worker_12','pwd_secure_112','+7 (999) 276-88-82','5436 713586',3),(13,'Андреева Анастасия Давидовна','worker_13','pwd_secure_113','+7 (999) 840-43-88','3095 276584',3),(14,'Попов Илья Вадимович','worker_14','pwd_secure_114','+7 (999) 833-28-56','9332 506487',3),(15,'Захаров Артем Константинович','worker_15','pwd_secure_115','+7 (999) 590-76-25','4126 137452',3),(16,'Кузнецова Алина Максимовна','worker_16','pwd_secure_116','+7 (999) 251-40-10','8353 381665',3),(17,'Степанов Илья Артурович','worker_17','pwd_secure_117','+7 (999) 855-61-75','4674 135402',3),(18,'Сергеева Марина Владимировна','worker_18','pwd_secure_118','+7 (999) 951-82-45','7162 458117',3),(19,'Пономарев Богдан Сергеевич','worker_19','pwd_secure_119','+7 (999) 624-91-23','6352 147596',3),(20,'Макаров Денис Антонович','worker_20','pwd_secure_120','+7 (999) 112-43-87','2165 498132',3),(21,'Александрова Ксения Петровна','worker_21','pwd_secure_121','+7 (999) 321-77-66','8451 965213',3),(22,'Николаева Полина Эдуардовна','worker_22','pwd_secure_122','+7 (999) 554-12-89','1264 784512',3),(23,'Фомина Милана Львовна','worker_23','pwd_secure_123','+7 (999) 652-33-44','3521 849652',3),(24,'Романов Егор Николаевич','worker_24','pwd_secure_124','+7 (999) 125-45-78','6251 354128',3),(25,'Козлов Роман Михайлович','worker_25','pwd_secure_125','+7 (999) 784-11-22','9512 846215',3),(26,'Ильина Алена Сергеевна','worker_26','pwd_secure_126','+7 (999) 451-99-00','1542 326514',3),(27,'Кудрявцева Кира Владимировна','worker_27','pwd_secure_127','+7 (999) 658-22-33','7451 984215',3),(28,'Гусев Лев Антонович','worker_28','pwd_secure_128','+7 (999) 352-77-88','3215 654128',3),(29,'Титова Диана Игоревна','worker_29','pwd_secure_129','+7 (999) 985-44-55','8451 125463',3),(30,'Ковалев Владислав Аркадьевич','worker_30','pwd_secure_130','+7 (999) 214-66-77','6523 984512',3),(31,'Киселева Ольга Дмитриевна','worker_31','pwd_secure_131','+7 (999) 651-11-44','7451 326598',3),(32,'Морозов Никита Олегович','worker_32','pwd_secure_132','+7 (999) 325-88-99','2154 654123',3),(33,'Новиков Дмитрий Петрович','worker_33','pwd_secure_133','+7 (999) 845-22-11','9854 321456',3),(34,'Соколов Максим Васильевич','worker_34','pwd_secure_134','+7 (999) 124-77-55','3521 654987',3),(35,'Васильева Елена Михайловна','worker_35','pwd_secure_135','+7 (999) 951-44-88','1542 987456',3),(36,'Смирнова Татьяна Юрьевна','worker_36','pwd_secure_136','+7 (999) 652-11-22','8451 321654',3),(37,'Кузнецов Алексей Андреевич','worker_37','pwd_secure_137','+7 (999) 352-88-77','6523 789456',3),(38,'Петров Александр Сергеевич','worker_38','pwd_secure_138','+7 (999) 214-55-66','7451 123456',3),(39,'Иванова Наталья Викторовна','worker_39','pwd_secure_139','+7 (999) 845-99-00','9854 654321',3),(40,'Павлова Юлия Евгеньевна','worker_40','pwd_secure_140','+7 (999) 124-33-44','3521 987654',3),(41,'Егоров Кирилл Русланович','worker_41','pwd_secure_141','+7 (999) 951-22-33','1542 456123',3),(42,'Семенова Кристина Анатольевна','worker_42','pwd_secure_142','+7 (999) 652-88-99','8451 654789',3),(43,'Лебедев Тимофей Вадимович','worker_43','pwd_secure_143','+7 (999) 352-44-55','6523 123789',3),(44,'Алексеева Ирина Маратовна','worker_44','pwd_secure_144','+7 (999) 214-11-22','7451 789123',3),(45,'Волков Матвей Филиппович','worker_45','pwd_secure_145','+7 (999) 845-77-88','9854 456789',3),(46,'Михайлова Вероника Романовна','worker_46','pwd_secure_146','+7 (999) 124-55-66','3521 321789',3),(47,'Соловьева Ева Давидовна','worker_47','pwd_secure_147','+7 (999) 951-33-44','1542 789321',3),(48,'Борисов Глеб Станиславович','worker_48','pwd_secure_148','+7 (999) 652-00-11','8451 987123',3),(49,'Яковлева Ангелина Савельевна','worker_49','pwd_secure_149','+7 (999) 352-66-77','6523 123987',3),(50,'Григорьев Савва Антонович','worker_50','pwd_secure_150','+7 (999) 214-44-55','7451 321987',3);
/*!40000 ALTER TABLE `worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'shoestore_db'
--

--
-- Dumping routines for database 'shoestore_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-29 13:09:02
