CREATE DATABASE  IF NOT EXISTS `shoestore_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `shoestore_db`;
-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: localhost    Database: shoestore_db
-- ------------------------------------------------------
-- Server version	9.7.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '40041139-77f3-11f1-96cb-047c163347a2:1-319';

--
-- Table structure for table `brand`
--

DROP TABLE IF EXISTS `brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brand` (
  `BrandId` int NOT NULL AUTO_INCREMENT,
  `BrandName` varchar(100) NOT NULL,
  PRIMARY KEY (`BrandId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brand`
--

LOCK TABLES `brand` WRITE;
/*!40000 ALTER TABLE `brand` DISABLE KEYS */;
INSERT INTO `brand` VALUES (1,'Nike'),(2,'Adidas'),(3,'Puma'),(4,'Rieker'),(5,'ECCO');
/*!40000 ALTER TABLE `brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoryshoes`
--

DROP TABLE IF EXISTS `categoryshoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categoryshoes` (
  `CategoryShoesId` int NOT NULL AUTO_INCREMENT,
  `CategoryShoesName` varchar(50) NOT NULL,
  PRIMARY KEY (`CategoryShoesId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoryshoes`
--

LOCK TABLES `categoryshoes` WRITE;
/*!40000 ALTER TABLE `categoryshoes` DISABLE KEYS */;
INSERT INTO `categoryshoes` VALUES (1,'Кроссовки'),(2,'Ботинки'),(3,'Туфли'),(4,'Сандалии');
/*!40000 ALTER TABLE `categoryshoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client` (
  `ClientId` int NOT NULL AUTO_INCREMENT,
  `ClientFIO` varchar(100) NOT NULL,
  `ClientPhone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ClientId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,'Васильев Дмитрий Олегович','+7 (910) 100-11-22'),(2,'Соколова Ольга Николаевна','+7 (910) 200-22-33'),(3,'Морозов Сергей Владимирович','+7 (910) 300-33-44'),(4,'Новикова Анна Дмитриевна','+7 (910) 400-44-55'),(5,'Федоров Артем Андреевич','+7 (910) 500-55-66'),(6,'Волкова Елена Сергеевна','+7 (910) 600-66-77'),(7,'Алексеев Максим Игоревич','+7 (910) 700-77-88'),(8,'Лебедева Наталья Викторовна','+7 (910) 800-88-99'),(9,'Семенов Егор Константинович','+7 (910) 900-99-00'),(10,'Егорова Ирина Васильевна','+7 (915) 111-00-11');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offersshoes`
--

DROP TABLE IF EXISTS `offersshoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `offersshoes` (
  `OffersShoesId` int NOT NULL AUTO_INCREMENT,
  `OffersShoesName` varchar(50) NOT NULL,
  `OffersShoesDiscount` int DEFAULT '0',
  PRIMARY KEY (`OffersShoesId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offersshoes`
--

LOCK TABLES `offersshoes` WRITE;
/*!40000 ALTER TABLE `offersshoes` DISABLE KEYS */;
INSERT INTO `offersshoes` VALUES (1,'Без скидки',0),(2,'Сезонная распродажа 10%',10),(3,'Акция 15%',15);
/*!40000 ALTER TABLE `offersshoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order` (
  `OrderId` int NOT NULL AUTO_INCREMENT,
  `WorkerId` int NOT NULL,
  `ClientId` int DEFAULT NULL,
  `OrderDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `OrderPrice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `OrderStatus` enum('Ожидание','В процессе','Выполнен','Отменён') DEFAULT 'Ожидание',
  `OrderStatusPayment` enum('Не оплачен','Оплачен','Возврат') DEFAULT 'Не оплачен',
  PRIMARY KEY (`OrderId`),
  KEY `WorkerId` (`WorkerId`),
  KEY `ClientId` (`ClientId`),
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`WorkerId`) REFERENCES `worker` (`WorkerId`),
  CONSTRAINT `order_ibfk_2` FOREIGN KEY (`ClientId`) REFERENCES `client` (`ClientId`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,3,1,'2026-08-01 10:15:00',12990.00,'Выполнен','Оплачен'),(2,3,2,'2026-08-02 11:30:00',14500.00,'Выполнен','Оплачен'),(3,4,3,'2026-08-03 14:20:00',19980.00,'Выполнен','Оплачен'),(4,4,4,'2026-08-05 16:45:00',8500.00,'Выполнен','Оплачен'),(5,5,5,'2026-08-06 12:00:00',18900.00,'Выполнен','Оплачен'),(6,3,6,'2026-08-08 15:10:00',5490.00,'Выполнен','Оплачен'),(7,4,7,'2026-08-10 18:30:00',8990.00,'Выполнен','Оплачен'),(8,5,8,'2026-08-12 09:40:00',9980.00,'Выполнен','Оплачен'),(9,3,9,'2026-08-13 13:15:00',15990.00,'Отменён','Возврат'),(10,4,10,'2026-08-15 17:00:00',6990.00,'Выполнен','Оплачен'),(11,5,1,'2026-08-17 11:25:00',18480.00,'Выполнен','Оплачен'),(12,3,3,'2026-08-19 14:50:00',14500.00,'Выполнен','Оплачен'),(13,4,5,'2026-08-20 16:10:00',9990.00,'Выполнен','Оплачен'),(14,5,2,'2026-08-22 10:05:00',8500.00,'Выполнен','Оплачен'),(15,3,4,'2026-08-25 12:40:00',18900.00,'Выполнен','Оплачен'),(16,4,6,'2026-08-27 15:30:00',17980.00,'Выполнен','Оплачен'),(17,5,7,'2026-08-29 17:15:00',4990.00,'Выполнен','Оплачен'),(18,3,8,'2026-09-01 10:00:00',6990.00,'Выполнен','Оплачен'),(19,4,9,'2026-09-03 11:45:00',12990.00,'Выполнен','Оплачен'),(20,5,10,'2026-09-05 13:20:00',14500.00,'Выполнен','Оплачен'),(21,3,2,'2026-09-08 14:00:00',16980.00,'Выполнен','Оплачен'),(22,4,1,'2026-09-10 16:50:00',8500.00,'Выполнен','Оплачен'),(23,5,4,'2026-09-12 18:10:00',18900.00,'Выполнен','Оплачен'),(24,3,6,'2026-09-15 11:30:00',16470.00,'Выполнен','Оплачен'),(25,4,3,'2026-09-18 12:15:00',8990.00,'Выполнен','Оплачен'),(26,5,5,'2026-09-20 15:00:00',4990.00,'В процессе','Оплачен'),(27,3,7,'2026-09-22 16:30:00',15990.00,'В процессе','Не оплачен'),(28,4,8,'2026-09-25 10:10:00',13980.00,'Ожидание','Не оплачен'),(29,5,9,'2026-09-27 14:40:00',12990.00,'Ожидание','Не оплачен'),(30,3,10,'2026-09-28 09:20:00',14500.00,'Ожидание','Не оплачен');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderitems`
--

DROP TABLE IF EXISTS `orderitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orderitems` (
  `OrderItemId` int NOT NULL AUTO_INCREMENT,
  `OrderId` int NOT NULL,
  `ShoesId` int NOT NULL,
  `ShoesCount` int NOT NULL DEFAULT '1',
  `PriceAtPurchase` decimal(10,2) NOT NULL,
  PRIMARY KEY (`OrderItemId`),
  KEY `OrderId` (`OrderId`),
  KEY `ShoesId` (`ShoesId`),
  CONSTRAINT `orderitems_ibfk_1` FOREIGN KEY (`OrderId`) REFERENCES `order` (`OrderId`) ON DELETE CASCADE,
  CONSTRAINT `orderitems_ibfk_2` FOREIGN KEY (`ShoesId`) REFERENCES `shoes` (`ShoesId`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderitems`
--

LOCK TABLES `orderitems` WRITE;
/*!40000 ALTER TABLE `orderitems` DISABLE KEYS */;
INSERT INTO `orderitems` VALUES (1,1,1,1,12990.00),(2,2,2,1,14500.00),(3,3,3,2,9990.00),(4,4,4,1,8500.00),(5,5,5,1,18900.00),(6,6,6,1,5490.00),(7,7,7,1,8990.00),(8,8,8,2,4990.00),(9,9,9,1,15990.00),(10,10,10,1,6990.00),(11,11,1,1,12990.00),(12,11,6,1,5490.00),(13,12,2,1,14500.00),(14,13,3,1,9990.00),(15,14,4,1,8500.00),(16,15,5,1,18900.00),(17,16,7,2,8990.00),(18,17,8,1,4990.00),(19,18,10,1,6990.00),(20,19,1,1,12990.00),(21,20,2,1,14500.00),(22,21,3,1,9990.00),(23,21,10,1,6990.00),(24,22,4,1,8500.00),(25,23,5,1,18900.00),(26,24,6,3,5490.00),(27,25,7,1,8990.00),(28,26,8,1,4990.00),(29,27,9,1,15990.00),(30,28,10,2,6990.00),(31,29,1,1,12990.00),(32,30,2,1,14500.00);
/*!40000 ALTER TABLE `orderitems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `RoleId` int NOT NULL AUTO_INCREMENT,
  `RoleName` varchar(200) NOT NULL,
  PRIMARY KEY (`RoleId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Администратор'),(2,'Менеджер'),(3,'Продавец');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shoes`
--

DROP TABLE IF EXISTS `shoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shoes` (
  `ShoesId` int NOT NULL AUTO_INCREMENT,
  `ShoesName` varchar(100) NOT NULL,
  `ShoesDescription` text,
  `ShoesSize` decimal(3,1) NOT NULL,
  `ShoesColor` varchar(30) NOT NULL,
  `ShoesPrice` decimal(10,2) NOT NULL,
  `ShoesQuantity` int NOT NULL DEFAULT '0',
  `ShoesCategory` int NOT NULL,
  `BrandId` int NOT NULL,
  `OffersShoes` int DEFAULT NULL,
  `ShoesPhoto` text,
  PRIMARY KEY (`ShoesId`),
  KEY `ShoesCategory` (`ShoesCategory`),
  KEY `BrandId` (`BrandId`),
  KEY `OffersShoes` (`OffersShoes`),
  CONSTRAINT `shoes_ibfk_1` FOREIGN KEY (`ShoesCategory`) REFERENCES `categoryshoes` (`CategoryShoesId`),
  CONSTRAINT `shoes_ibfk_2` FOREIGN KEY (`BrandId`) REFERENCES `brand` (`BrandId`),
  CONSTRAINT `shoes_ibfk_3` FOREIGN KEY (`OffersShoes`) REFERENCES `offersshoes` (`OffersShoesId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shoes`
--

LOCK TABLES `shoes` WRITE;
/*!40000 ALTER TABLE `shoes` DISABLE KEYS */;
INSERT INTO `shoes` VALUES (1,'Air Max 270','Удобные повседневные кроссовки',42.0,'Черный',12990.00,15,1,1,1,'nike_air_max.jpg'),(2,'Ultraboost Light','Беговые кроссовки с амортизацией',41.5,'Белый',14500.00,10,1,2,2,'adidas_ultraboost.jpg'),(3,'RS-X Efekt','Стильные массивные кроссовки',43.0,'Серый',9990.00,8,1,3,1,'puma_rsx.jpg'),(4,'Классические дерби','Кожаные мужские туфли',42.5,'Коричневый',8500.00,12,3,4,1,'rieker_derby.jpg'),(5,'Ботинки мембранные','Зимние непромокаемые ботинки',44.0,'Черный',18900.00,6,2,5,3,'ecco_boots.jpg'),(6,'Star Runner 3','Детские/подростковые кроссовки',38.0,'Синий',5490.00,20,1,1,1,'nike_star.jpg'),(7,'Gazelle Vintage','Замшевые классические кроссовки',40.0,'Зеленый',8990.00,14,1,2,2,'adidas_gazelle.jpg'),(8,'Кожаные сандалии','Летние комфортные сандалии',41.0,'Бежевый',4990.00,18,4,4,1,'rieker_sandals.jpg'),(9,'CityTray Аксфорд','Элегантные мужские туфли',43.0,'Черный',15990.00,5,3,5,1,'ecco_oxford.jpg'),(10,'Caven 2.0','Повседневные кеды',42.0,'Белый',6990.00,25,1,3,1,'puma_caven.jpg');
/*!40000 ALTER TABLE `shoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker`
--

DROP TABLE IF EXISTS `worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worker` (
  `WorkerId` int NOT NULL AUTO_INCREMENT,
  `WorkerFIO` varchar(100) NOT NULL,
  `WorkerLogin` varchar(50) NOT NULL,
  `WorkerPassword` varchar(200) NOT NULL,
  `WorkerPhone` varchar(20) NOT NULL,
  `WorkerPassport` varchar(20) NOT NULL,
  `WorkerRole` int NOT NULL,
  PRIMARY KEY (`WorkerId`),
  UNIQUE KEY `WorkerLogin` (`WorkerLogin`),
  KEY `WorkerRole` (`WorkerRole`),
  CONSTRAINT `worker_ibfk_1` FOREIGN KEY (`WorkerRole`) REFERENCES `role` (`RoleId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker`
--

LOCK TABLES `worker` WRITE;
/*!40000 ALTER TABLE `worker` DISABLE KEYS */;
INSERT INTO `worker` VALUES (1,'Иванов Иван Сергеевич','admin','admin123','+7 (999) 111-22-33','4510 123456',1),(2,'Петрова Анна Алексеевна','manager','mgr123','+7 (999) 222-33-44','4511 234567',2),(3,'Сидоров Алексей Дмитриевич','seller1','pass123','+7 (999) 333-44-55','4512 345678',3),(4,'Смирнова Елена Михайловна','seller2','pass123','+7 (999) 444-55-66','4513 456789',3),(5,'Кузнецов Павел Игоревич','seller3','pass123','+7 (999) 555-66-77','4514 567890',3);
/*!40000 ALTER TABLE `worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'shoestore_db'
--

--
-- Dumping routines for database 'shoestore_db'
--
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-28 19:04:02
